# Troubleshooting Guide

## EAS CLI Permission Issues

### Problem: EACCES permission denied errors
```
npm error code EACCES
npm error syscall mkdir
npm error path /usr/local/lib/node_modules/eas-cli
npm error errno -13
```

### Solutions (in order of preference):

#### 1. Use npx (Recommended - No Installation Required)
```bash
# Instead of installing globally, use npx
npx eas-cli@latest init --id 6d256b00-ea43-48ab-97ed-d075954d4bd9
npx eas-cli@latest build --profile development

# Or use npm scripts
npm run eas:init
npm run build:dev
```

#### 2. Fix npm permissions automatically
```bash
# Run our permission fix script
./scripts/fix-permissions.sh

# Restart terminal, then try again
npm install -g eas-cli
```

#### 3. Manual permission fix
```bash
# Create npm global directory
mkdir ~/.npm-global

# Configure npm
npm config set prefix '~/.npm-global'

# Add to PATH
echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.zshrc
source ~/.zshrc

# Now install
npm install -g eas-cli
```

#### 4. Use Node Version Manager (NVM)
```bash
# Install nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# Install latest Node
nvm install node
nvm use node

# Now npm works without sudo
npm install -g eas-cli
```

#### 5. Homebrew (macOS only)
```bash
brew install eas-cli
```

## Build Issues

### Problem: Build configuration errors
```
Error: eas.json not found
```

**Solution:**
```bash
npx eas-cli@latest build:configure
```

### Problem: App.json validation errors
**Solution:** Check app.json for:
- Valid bundle identifier
- Correct version numbers
- Proper permission descriptions

### Problem: TypeScript errors during build
**Solution:**
```bash
npm run type-check
# Fix any TypeScript errors shown
```

## Development Issues

### Problem: Metro bundler errors
**Solution:**
```bash
# Clear Metro cache
npx expo start --clear

# Or reset completely
rm -rf node_modules
npm install
```

### Problem: Simulator/Emulator not launching
**Solution:**
```bash
# iOS
npx expo run:ios

# Android
npx expo run:android
```

### Problem: Hot reload not working
**Solution:**
```bash
# Restart with tunnel
npx expo start --tunnel
```

## Environment Issues

### Problem: Node version compatibility
**Solution:**
```bash
# Check Node version
node --version

# Should be 18+ for Expo SDK 50
# Use nvm to switch if needed
nvm use 18
```

### Problem: Missing dependencies
**Solution:**
```bash
# Clean install
rm -rf node_modules package-lock.json
npm install
```

## Deployment Issues

### Problem: Submission failures
**Solution:**
```bash
# Check build status
npx eas-cli@latest build:list

# View specific build logs
npx eas-cli@latest build:view [build-id]
```

### Problem: App Store Connect errors
**Solution:**
- Verify bundle ID matches App Store Connect
- Check version numbers are incremented
- Ensure all required metadata is filled

## Quick Fixes

### Reset everything
```bash
# Nuclear option - start fresh
rm -rf node_modules package-lock.json
npm install
npx expo install --fix
```

### Check project health
```bash
# Run diagnostics
npx expo doctor

# Check for updates
npx expo install --fix
```

### Get help
```bash
# EAS CLI help
npx eas-cli@latest --help

# Expo CLI help
npx expo --help
```

## Still Having Issues?

1. Check [Expo Documentation](https://docs.expo.dev/)
2. Search [Expo Forums](https://forums.expo.dev/)
3. Check [GitHub Issues](https://github.com/expo/expo/issues)
4. Use our automated scripts in `/scripts/` directory

---

**Remember: When in doubt, use npx instead of global installations!** 🚀
