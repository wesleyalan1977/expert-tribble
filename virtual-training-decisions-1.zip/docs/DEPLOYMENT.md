# Deployment Guide

## EAS CLI Permission Issues

If you're encountering permission errors when installing EAS CLI, here are the solutions:

### Quick Fix (Recommended)
```bash
# Use npx instead of global installation
npx eas-cli@latest build --platform all
npx eas-cli@latest submit
```

### Permanent Solutions

#### Option 1: Fix npm Global Directory
```bash
# Create npm global directory in your home folder
mkdir ~/.npm-global

# Configure npm to use it
npm config set prefix '~/.npm-global'

# Add to PATH in your shell profile
echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.zshrc
# or for bash: echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.bashrc

# Reload shell
source ~/.zshrc  # or ~/.bashrc

# Now install EAS CLI
npm install -g eas-cli
```

#### Option 2: Use Node Version Manager
```bash
# Install nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# Install latest Node.js
nvm install node
nvm use node

# Now npm global installs work without sudo
npm install -g eas-cli
```

#### Option 3: Homebrew (macOS)
```bash
brew install eas-cli
```

## Build Configuration

### Initial Setup
```bash
# Configure EAS for your project
npx eas build:configure

# This creates eas.json with build profiles
```

### Build Commands
```bash
# Development build
npx eas build --profile development

# Preview build (for testing)
npx eas build --profile preview

# Production build
npx eas build --profile production

# Build for specific platform
npx eas build --platform ios
npx eas build --platform android
```

### App Store Submission
```bash
# Submit to App Store
npx eas submit --platform ios

# Submit to Google Play
npx eas submit --platform android
```

## Environment Variables

Create `.env` file for local development:
```
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_supabase_anon_key
```

For EAS builds, add secrets:
```bash
npx eas secret:create --scope project --name SUPABASE_URL --value your_url
npx eas secret:create --scope project --name SUPABASE_ANON_KEY --value your_key
```

## Troubleshooting

### Common Permission Errors
- **EACCES**: Use npx or fix npm permissions
- **EPERM**: Check file/folder permissions
- **ENOENT**: Ensure all dependencies are installed

### Build Failures
- Check eas.json configuration
- Verify app.json settings
- Ensure all assets are properly referenced
- Check for TypeScript errors

### Debugging
```bash
# View build logs
npx eas build:list

# View specific build
npx eas build:view [build-id]
```