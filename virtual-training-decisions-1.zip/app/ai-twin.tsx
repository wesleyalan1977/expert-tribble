import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, LinearGradient } from 'react-native';
import AITwinPersonalityForm from '../components/AITwinPersonalityForm';
import AIAvatar from '../components/AIAvatar';
import AITwinNaming from '../components/AITwinNaming';
import ConversationListener from '../components/ConversationListener';
import RedFlagAnalysis from '../components/RedFlagAnalysis';
import AvatarBuilder from '../components/AvatarBuilder';
import { useAITwin } from '../hooks/useAITwin';
import { useConversation } from '../hooks/useConversation';

interface RedFlag {
  id: string;
  analysis: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high';
}

export default function MelchizedekTab() {
  const [currentView, setCurrentView] = useState<'main' | 'avatar'>('main');
  const { 
    personalityData, 
    aiMood, 
    aiTwinName,
    redFlags,
    isListening,
    updatePersonality,
    updateAITwinName,
    analyzeConversation,
    toggleListening,
    clearRedFlags
  } = useAITwin();
  const { addDetectedTraits } = useConversation();

  const handlePersonalityUpdate = (data: { issues: string[]; strengths: string[] }) => {
    updatePersonality(data);
    const traits = [...data.issues, ...data.strengths];
    addDetectedTraits(traits);
  };

  const handleRedFlagDetected = (analysis: string) => {
    console.log('Red flag detected:', analysis);
  };

  const totalTraits = personalityData.issues.length + personalityData.strengths.length;
  const displayName = aiTwinName || 'MELCHIZEDEK';

  if (currentView === 'avatar') {
    return (
      <View style={styles.container}>
        <View style={styles.avatarHeader}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setCurrentView('main')}
          >
            <Text style={styles.backButtonText}>← BACK</Text>
          </TouchableOpacity>
        </View>
        <AvatarBuilder />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.crownContainer}>
          <Text style={styles.crown}>👑</Text>
          <AIAvatar mood={aiMood} size={80} />
        </View>
        <View style={styles.headerText}>
          <Text style={styles.title}>{displayName}</Text>
          <Text style={styles.subtitle}>KING OF RIGHTEOUSNESS</Text>
          <Text style={styles.status}>
            {isListening ? '🔴 MONITORING REALM' : 
             totalTraits > 0 ? `${totalTraits} TRAITS IDENTIFIED` : 'LEARNING YOUR DOMAIN'}
          </Text>
        </View>
        <TouchableOpacity 
          style={styles.avatarButton}
          onPress={() => setCurrentView('avatar')}
        >
          <Text style={styles.avatarButtonText}>⚔️</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>👑 ROYAL IDENTITY</Text>
          <AITwinNaming onNameSet={updateAITwinName} currentName={displayName} />
        </View>
        
        <View style={styles.card}>
          <Text style={styles.cardTitle}>🛡️ REALM GUARDIAN</Text>
          <ConversationListener 
            isListening={isListening}
            onToggleListening={toggleListening}
            onRedFlagDetected={handleRedFlagDetected}
            onAnalyzeConversation={analyzeConversation}
            aiTwinName={displayName}
          />
        </View>
        
        <View style={styles.card}>
          <Text style={styles.cardTitle}>⚡ THREAT ANALYSIS</Text>
          <RedFlagAnalysis redFlags={redFlags} onClearFlags={clearRedFlags} />
        </View>
        
        <View style={styles.card}>
          <Text style={styles.cardTitle}>🧠 WISDOM MATRIX</Text>
          <AITwinPersonalityForm 
            onSubmit={handlePersonalityUpdate} 
            initialData={personalityData}
            isAIMode={true}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#1a1a1a',
    borderBottomWidth: 2,
    borderBottomColor: '#ff6b35',
  },
  crownContainer: {
    position: 'relative',
    alignItems: 'center',
  },
  crown: {
    fontSize: 24,
    position: 'absolute',
    top: -15,
    zIndex: 1,
  },
  headerText: {
    marginLeft: 20,
    flex: 1,
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: '#ff6b35',
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 12,
    color: '#888',
    marginTop: 2,
    letterSpacing: 1,
    fontWeight: '600',
  },
  status: {
    fontSize: 12,
    color: '#fff',
    marginTop: 4,
    fontWeight: '500',
  },
  avatarButton: {
    backgroundColor: '#ff6b35',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarButtonText: {
    fontSize: 20,
  },
  avatarHeader: {
    backgroundColor: '#1a1a1a',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 10,
    borderBottomWidth: 2,
    borderBottomColor: '#ff6b35',
  },
  backButton: {
    alignSelf: 'flex-start',
  },
  backButtonText: {
    color: '#ff6b35',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 1,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#333',
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#ff6b35',
    marginBottom: 16,
    letterSpacing: 1,
  },
});