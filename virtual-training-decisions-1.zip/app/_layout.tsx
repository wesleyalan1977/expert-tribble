import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

export default function RootLayout() {
  return (
    <>
      <StatusBar style="light" backgroundColor="#0a0a0a" />
      <Tabs
        screenOptions={{
          tabBarActiveTintColor: '#ffd700',
          tabBarInactiveTintColor: '#666',
          tabBarStyle: {
            backgroundColor: '#1a1a1a',
            borderTopWidth: 2,
            borderTopColor: '#ffd700',
            height: 65,
            paddingBottom: 8,
            paddingTop: 8,
            shadowColor: '#ffd700',
            shadowOffset: { width: 0, height: -2 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
          },
          tabBarLabelStyle: {
            fontSize: 10,
            fontWeight: 'bold',
            letterSpacing: 0.5,
          },
          headerStyle: {
            backgroundColor: '#1a1a1a',
            borderBottomWidth: 2,
            borderBottomColor: '#ffd700',
            shadowColor: '#ffd700',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
          },
          headerTintColor: '#ffd700',
          headerTitleStyle: {
            fontWeight: 'bold',
            letterSpacing: 1,
          },
        }}
      >
        <Tabs.Screen
          name="index"
          options={{
            title: 'COMMAND',
            headerTitle: '👑 MELCHIZEDEK COMMAND',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="flash" size={22} color={color} />
            ),
          }}
        />
        <Tabs.Screen
          name="self"
          options={{
            title: 'SELF',
            headerTitle: '👤 KNOW THYSELF',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="person" size={22} color={color} />
            ),
          }}
        />
        <Tabs.Screen
          name="constitution"
          options={{
            title: 'LAW',
            headerTitle: '📜 SACRED CONSTITUTION',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="document-text" size={22} color={color} />
            ),
          }}
        />
        <Tabs.Screen
          name="ai-twin"
          options={{
            title: 'AI',
            headerTitle: '💎 MELCHIZEDEK AI',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="diamond" size={22} color={color} />
            ),
          }}
        />
        <Tabs.Screen
          name="goals"
          options={{
            title: 'GOALS',
            headerTitle: '🏆 ROYAL QUESTS',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="flag" size={22} color={color} />
            ),
          }}
        />
        <Tabs.Screen
          name="train"
          options={{
            title: 'TRAIN',
            headerTitle: '⚔️ BATTLE TRAINING',
            tabBarIcon: ({ color, size }) => (
              <Ionicons name="fitness" size={22} color={color} />
            ),
          }}
        />
        <Tabs.Screen
          name="subscription"
          options={{
            href: null,
          }}
        />
      </Tabs>
    </>
  );
}