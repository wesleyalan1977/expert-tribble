import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { GritMeasure } from '../components/GritMeasure';
import { useUserActivity } from '../hooks/useUserActivity';
import { supabase } from './lib/supabase';

export default function Index() {
  const { continuousDays, isEligible } = useUserActivity();
  const router = useRouter();
  
  const handleEasyPathWarning = () => {
    Alert.alert(
      '⚠️ WARNING',
      'Choosing easy paths will reset your 180-day tracker and log you out. No victory shall be given to those who quit.',
      [{ text: 'I Understand', style: 'default' }]
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <LinearGradient
          colors={['#1a1a1a', '#2a2a2a', '#1a1a1a']}
          style={styles.header}
        >
          <Text style={styles.title}>👑 MELCHIZEDEK'S COMMAND</Text>
          <Text style={styles.subtitle}>Royal Path to Mastery</Text>
          <View style={styles.tracker}>
            <Text style={styles.trackerText}>DAY {continuousDays} OF 180</Text>
            <Text style={styles.trackerSubtext}>
              {isEligible ? '🏆 VICTORY ACHIEVED' : '⚔️ STAY STRONG'}
            </Text>
          </View>
        </LinearGradient>

        <TouchableOpacity style={styles.warningCard} onPress={handleEasyPathWarning}>
          <LinearGradient
            colors={['#2a1a1a', '#1a1a1a']}
            style={styles.warningGradient}
          >
            <Text style={styles.warningIcon}>⚠️</Text>
            <Text style={styles.warningText}>EASY PATH = RESET & LOGOUT</Text>
            <Text style={styles.warningSubtext}>Choose wisely in all decisions</Text>
          </LinearGradient>
        </TouchableOpacity>

        <View style={styles.menuSection}>
          <Text style={styles.menuTitle}>🏛️ ROYAL CHAMBERS</Text>
          <View style={styles.menuGrid}>
            <Link href="/self" asChild>
              <TouchableOpacity style={styles.menuCard}>
                <LinearGradient
                  colors={['#2a2a2a', '#1a1a1a']}
                  style={styles.menuCardGradient}
                >
                  <Text style={styles.menuIcon}>👤</Text>
                  <Text style={styles.menuLabel}>SELF</Text>
                  <Text style={styles.menuDesc}>Know Thyself</Text>
                </LinearGradient>
              </TouchableOpacity>
            </Link>

            <Link href="/constitution" asChild>
              <TouchableOpacity style={styles.menuCard}>
                <LinearGradient
                  colors={['#2a2a2a', '#1a1a1a']}
                  style={styles.menuCardGradient}
                >
                  <Text style={styles.menuIcon}>📜</Text>
                  <Text style={styles.menuLabel}>CONSTITUTION</Text>
                  <Text style={styles.menuDesc}>Sacred Laws</Text>
                </LinearGradient>
              </TouchableOpacity>
            </Link>

            <Link href="/ai-twin" asChild>
              <TouchableOpacity style={styles.menuCard}>
                <LinearGradient
                  colors={['#2a2a2a', '#1a1a1a']}
                  style={styles.menuCardGradient}
                >
                  <Text style={styles.menuIcon}>💎</Text>
                  <Text style={styles.menuLabel}>MELCHIZEDEK</Text>
                  <Text style={styles.menuDesc}>AI Wisdom</Text>
                </LinearGradient>
              </TouchableOpacity>
            </Link>

            <Link href="/goals" asChild>
              <TouchableOpacity style={styles.menuCard}>
                <LinearGradient
                  colors={['#2a2a2a', '#1a1a1a']}
                  style={styles.menuCardGradient}
                >
                  <Text style={styles.menuIcon}>🏆</Text>
                  <Text style={styles.menuLabel}>GOALS</Text>
                  <Text style={styles.menuDesc}>Royal Quests</Text>
                </LinearGradient>
              </TouchableOpacity>
            </Link>

            <Link href="/train" asChild>
              <TouchableOpacity style={styles.menuCard}>
                <LinearGradient
                  colors={['#2a2a2a', '#1a1a1a']}
                  style={styles.menuCardGradient}
                >
                  <Text style={styles.menuIcon}>⚔️</Text>
                  <Text style={styles.menuLabel}>TRAIN</Text>
                  <Text style={styles.menuDesc}>Battle Ready</Text>
                </LinearGradient>
              </TouchableOpacity>
            </Link>

            <GritMeasure />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  content: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingTop: 40,
    borderBottomWidth: 2,
    borderBottomColor: '#ffd700',
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffd700',
    textAlign: 'center',
    letterSpacing: 2,
    textShadowColor: '#ffd700',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#ff6b35',
    textAlign: 'center',
    marginTop: 5,
    fontStyle: 'italic',
  },
  tracker: {
    marginTop: 15,
    padding: 15,
    backgroundColor: '#2a2a2a',
    borderRadius: 15,
    borderWidth: 2,
    borderColor: '#ff6b35',
    shadowColor: '#ff6b35',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
  },
  trackerText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    letterSpacing: 1,
  },
  trackerSubtext: {
    fontSize: 12,
    color: '#ff6b35',
    textAlign: 'center',
    marginTop: 4,
  },
  warningCard: {
    margin: 16,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: '#ff6b35',
    shadowColor: '#ff6b35',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  warningGradient: {
    padding: 16,
    borderRadius: 13,
    alignItems: 'center',
  },
  warningIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  warningText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ff6b35',
    textAlign: 'center',
    letterSpacing: 1,
  },
  warningSubtext: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    marginTop: 4,
  },
  menuSection: {
    margin: 16,
    padding: 20,
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    borderWidth: 2,
    borderColor: '#ffd700',
    shadowColor: '#ffd700',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  menuTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffd700',
    textAlign: 'center',
    marginBottom: 20,
    letterSpacing: 1,
  },
  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 15,
  },
  menuCard: {
    width: '48%',
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#ff6b35',
    shadowColor: '#ff6b35',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  menuCardGradient: {
    padding: 20,
    borderRadius: 14,
    alignItems: 'center',
  },
  menuIcon: {
    fontSize: 32,
    marginBottom: 10,
  },
  menuLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 5,
    letterSpacing: 0.5,
  },
  menuDesc: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
  },
});