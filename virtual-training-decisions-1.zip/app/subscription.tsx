import React from 'react';
import { View, StyleSheet } from 'react-native';
import { PurchaseManager } from '../components/PurchaseManager';

export default function Subscription() {
  return (
    <View style={styles.container}>
      <PurchaseManager />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
});