import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface ConstitutionPrinciple {
  id: string;
  title: string;
  description: string;
  editable?: boolean;
}

export default function ConstitutionScreen() {
  const [principles, setPrinciples] = useState<ConstitutionPrinciple[]>([
    {
      id: '1',
      title: 'I AM THE KING OF MY DOMAIN',
      description: 'I take full responsibility for my choices and their consequences. No excuses, no blame.'
    },
    {
      id: '2', 
      title: 'RESPECT IS EARNED, NOT GIVEN',
      description: 'I command respect through my actions, integrity, and unwavering principles.'
    },
    {
      id: '3',
      title: 'STRENGTH THROUGH DISCIPLINE',
      description: 'I forge my character through daily discipline and relentless self-improvement.'
    }
  ]);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');

  const addPrinciple = () => {
    if (!newTitle.trim() || !newDescription.trim()) {
      Alert.alert('Error', 'Please fill in both title and description');
      return;
    }

    const newPrinciple: ConstitutionPrinciple = {
      id: Date.now().toString(),
      title: newTitle.toUpperCase(),
      description: newDescription
    };

    setPrinciples([...principles, newPrinciple]);
    setNewTitle('');
    setNewDescription('');
  };

  const deletePrinciple = (id: string) => {
    setPrinciples(principles.filter(p => p.id !== id));
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>MY CONSTITUTION</Text>
        <Text style={styles.subtitle}>THE UNBREAKABLE LAWS I LIVE BY</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {principles.map((principle, index) => (
          <View key={principle.id} style={styles.principleCard}>
            <View style={styles.principleHeader}>
              <Text style={styles.principleNumber}>ARTICLE {index + 1}</Text>
              <TouchableOpacity 
                onPress={() => deletePrinciple(principle.id)}
                style={styles.deleteButton}
              >
                <Ionicons name="trash-outline" size={20} color="#ff4444" />
              </TouchableOpacity>
            </View>
            <Text style={styles.principleTitle}>{principle.title}</Text>
            <Text style={styles.principleDescription}>{principle.description}</Text>
          </View>
        ))}

        <View style={styles.addSection}>
          <Text style={styles.addTitle}>ADD NEW PRINCIPLE</Text>
          <TextInput
            style={styles.input}
            placeholder="PRINCIPLE TITLE"
            placeholderTextColor="#666"
            value={newTitle}
            onChangeText={setNewTitle}
            multiline={false}
          />
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="Describe your principle..."
            placeholderTextColor="#666"
            value={newDescription}
            onChangeText={setNewDescription}
            multiline={true}
            numberOfLines={3}
          />
          <TouchableOpacity style={styles.addButton} onPress={addPrinciple}>
            <Ionicons name="add" size={24} color="white" />
            <Text style={styles.addButtonText}>FORGE NEW PRINCIPLE</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    padding: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#ff6b35',
    backgroundColor: '#1a1a1a',
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: '#ff6b35',
    textAlign: 'center',
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 14,
    color: '#ccc',
    textAlign: 'center',
    marginTop: 5,
    letterSpacing: 1,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  principleCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 8,
    padding: 20,
    marginBottom: 20,
    borderLeftWidth: 4,
    borderLeftColor: '#ff6b35',
  },
  principleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  principleNumber: {
    fontSize: 12,
    color: '#ff6b35',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  deleteButton: {
    padding: 5,
  },
  principleTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 10,
    letterSpacing: 1,
  },
  principleDescription: {
    fontSize: 16,
    color: '#ccc',
    lineHeight: 24,
  },
  addSection: {
    backgroundColor: '#1a1a1a',
    borderRadius: 8,
    padding: 20,
    marginTop: 20,
    borderWidth: 2,
    borderColor: '#333',
    borderStyle: 'dashed',
  },
  addTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ff6b35',
    marginBottom: 15,
    textAlign: 'center',
    letterSpacing: 1,
  },
  input: {
    backgroundColor: '#2a2a2a',
    borderRadius: 6,
    padding: 15,
    color: 'white',
    fontSize: 16,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#444',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  addButton: {
    backgroundColor: '#ff6b35',
    borderRadius: 6,
    padding: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    marginLeft: 8,
    letterSpacing: 1,
  },
});