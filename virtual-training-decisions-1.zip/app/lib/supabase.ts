import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://ysdrwaiivfkjpdgbujdn.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlzZHJ3YWlpdmZranBkZ2J1amRuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAxMTE2MTYsImV4cCI6MjA2NTY4NzYxNn0.16TrMUav122I3kwYLQFQXN1GaVg3aTyu6Qab10mhXgU';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };