import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import GoalPathSelector from '../components/GoalPathSelector';
import AIAvatar from '../components/AIAvatar';
import { useAITwin } from '../hooks/useAITwin';

export default function GoalsTab() {
  const { aiMood } = useAITwin();
  const [selectedPaths, setSelectedPaths] = useState<{[key: string]: 'easy' | 'hard'}>({});

  const handlePathSelected = (goalId: string, pathType: 'easy' | 'hard') => {
    setSelectedPaths(prev => ({ ...prev, [goalId]: pathType }));
  };

  const hardPathCount = Object.values(selectedPaths).filter(path => path === 'hard').length;
  const totalSelections = Object.keys(selectedPaths).length;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.crown}>👑</Text>
        <AIAvatar mood={aiMood} size={80} />
        <View style={styles.headerText}>
          <Text style={styles.title}>GOALS</Text>
          <Text style={styles.subtitle}>KING OF RIGHTEOUSNESS</Text>
          {totalSelections > 0 && (
            <Text style={styles.pathStats}>
              {hardPathCount}/{totalSelections} HARD PATHS CHOSEN
            </Text>
          )}
        </View>
      </View>

      <View style={styles.content}>
        <GoalPathSelector onPathSelected={handlePathSelected} />
        
        {totalSelections > 0 && (
          <View style={styles.wisdomCard}>
            <Text style={styles.wisdomTitle}>📜 MELCHIZEDEK'S WISDOM</Text>
            <Text style={styles.wisdomText}>
              {hardPathCount === totalSelections
                ? "You have chosen the path of kings. Self-reliance and self-respect are the foundations of true power."
                : hardPathCount > totalSelections / 2
                ? "You lean toward strength, but some easy paths remain. Consider where you might build more self-reliance."
                : "Many choose comfort over growth. Remember: the hard path builds the character that attracts what you truly want."}
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#1a1a1a',
    borderBottomWidth: 2,
    borderBottomColor: '#f59e0b',
  },
  crown: {
    fontSize: 32,
    marginRight: 8,
  },
  headerText: {
    marginLeft: 16,
    flex: 1,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#f59e0b',
  },
  subtitle: {
    fontSize: 14,
    color: '#d1d5db',
    marginTop: 4,
  },
  pathStats: {
    fontSize: 12,
    color: '#f59e0b',
    marginTop: 4,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    backgroundColor: '#000000',
  },
  wisdomCard: {
    margin: 20,
    padding: 20,
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#f59e0b',
  },
  wisdomTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#f59e0b',
    marginBottom: 12,
    textAlign: 'center',
  },
  wisdomText: {
    fontSize: 16,
    color: '#d1d5db',
    lineHeight: 24,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});
