import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import TrainingConversation from '@/components/TrainingConversation';
import DecisionMaker from '@/components/DecisionMaker';
import DecisionCard from '@/components/DecisionCard';
import { supabase } from './lib/supabase';

interface Decision {
  id: string;
  scenario: string;
  userChoice: string;
  aiSuggestion: string;
  confidence: number;
}

export default function TrainTab() {
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  const handleCreateDecision = async (scenario: string, userChoice: string) => {
    setIsLoading(true);
    try {
      const aiSuggestion = generateAISuggestion(scenario, userChoice);
      const confidence = Math.floor(Math.random() * 30) + 70;
      
      const newDecision: Decision = {
        id: Date.now().toString(),
        scenario,
        userChoice,
        aiSuggestion,
        confidence
      };
      
      setDecisions(prev => [newDecision, ...prev]);
    } catch (error) {
      console.error('Error creating decision:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const generateAISuggestion = (scenario: string, userChoice: string): string => {
    const hardPathSuggestions = [
      "Push through the challenge - growth comes from discomfort",
      "Face this head-on with discipline and commitment",
      "Take the harder path that builds character",
      "Embrace the struggle - it will make you stronger",
      "Choose the path that requires more effort but builds resilience"
    ];
    
    return hardPathSuggestions[Math.floor(Math.random() * hardPathSuggestions.length)];
  };

  const handleDecisionSelect = async (choice: 'user' | 'ai') => {
    if (choice === 'user') {
      console.log('User chose their path');
    } else {
      console.log('User chose AI suggestion - good choice!');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>👑 ROYAL TRAINING GROUNDS</Text>
        <Text style={styles.subtitle}>with King Melchizedek</Text>
        <Text style={styles.quote}>
          "People will judge you by the decisions you have made{"\n"}
          without ever knowing what options you had."
        </Text>
        <Text style={styles.wisdom}>⚔️ Choose wisely - easy paths reset progress ⚔️</Text>
      </View>
      
      <ScrollView style={styles.content}>
        <DecisionMaker 
          onCreateDecision={handleCreateDecision}
          aiMood={isLoading ? 'thinking' : 'confident'}
        />
        
        {decisions.map(decision => (
          <DecisionCard
            key={decision.id}
            title={decision.scenario}
            userChoice={decision.userChoice}
            aiSuggestion={decision.aiSuggestion}
            confidence={decision.confidence}
            onSelect={handleDecisionSelect}
          />
        ))}
        
        <TrainingConversation />
      </ScrollView>
      
      
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          🏆 True strength lies in seeing all paths and choosing the righteous one
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  header: {
    padding: 20,
    backgroundColor: '#1f2937',
    borderBottomWidth: 3,
    borderBottomColor: '#f97316',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: '900',
    color: '#f97316',
    textAlign: 'center',
    marginBottom: 4,
    letterSpacing: 1,
  },
  subtitle: {
    fontSize: 16,
    color: '#d97706',
    fontStyle: 'italic',
    marginBottom: 12,
  },
  quote: {
    fontSize: 14,
    color: '#e5e7eb',
    textAlign: 'center',
    fontStyle: 'italic',
    marginBottom: 8,
    lineHeight: 20,
  },
  wisdom: {
    fontSize: 12,
    color: '#f97316',
    textAlign: 'center',
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  footer: {
    padding: 16,
    backgroundColor: '#1f2937',
    borderTopWidth: 2,
    borderTopColor: '#f97316',
  },
  footerText: {
    fontSize: 12,
    color: '#d97706',
    textAlign: 'center',
    fontStyle: 'italic',
  },
});