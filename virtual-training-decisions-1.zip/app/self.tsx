import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import PersonalityForm from '../components/PersonalityForm';
import SelfWorthTracker from '../components/SelfWorthTracker';
import GrowthJournal from '../components/GrowthJournal';
import AIAvatar from '../components/AIAvatar';
import { useAITwin } from '../hooks/useAITwin';
import { useConversation } from '../hooks/useConversation';

type ActiveView = 'questions' | 'personality' | 'worth-tracker' | 'journal';

export default function SelfTab() {
  const [activeView, setActiveView] = useState<ActiveView>('questions');
  const [answers, setAnswers] = useState({
    question1: '',
    question2: '',
    question3: ''
  });
  const { personalityData, aiMood, updatePersonality } = useAITwin();
  const { addDetectedTraits } = useConversation();

  const handlePersonalityUpdate = (data: { issues: string[]; strengths: string[] }) => {
    updatePersonality(data);
    const traits = [...data.issues, ...data.strengths];
    addDetectedTraits(traits);
  };

  const handleAnswerChange = (question: string, value: string) => {
    setAnswers(prev => ({ ...prev, [question]: value }));
  };

  const saveAnswers = () => {
    Alert.alert('ANSWERS LOGGED', 'Your responses have been recorded for analysis.');
  };

  const totalTraits = personalityData.issues.length + personalityData.strengths.length;

  const renderContent = () => {
    switch (activeView) {
      case 'questions':
        return (
          <View style={styles.questionsContainer}>
            <Text style={styles.sectionTitle}>FOUNDATIONAL ASSESSMENT</Text>
            <Text style={styles.sectionSubtitle}>Answer these core questions with brutal honesty</Text>
            
            <View style={styles.questionBlock}>
              <Text style={styles.questionNumber}>QUESTION #1</Text>
              <Text style={styles.questionText}>WHO DO YOU TALK ABOUT BEHIND THEIR BACK?</Text>
              <TextInput
                style={styles.answerInput}
                value={answers.question1}
                onChangeText={(text) => handleAnswerChange('question1', text)}
                placeholder="Be honest about your gossip habits..."
                placeholderTextColor="#666"
                multiline
              />
            </View>

            <View style={styles.questionBlock}>
              <Text style={styles.questionNumber}>QUESTION #2</Text>
              <Text style={styles.questionText}>WHO HOLDS THE TOP POSITION IN YOUR HEART?</Text>
              <TextInput
                style={styles.answerInput}
                value={answers.question2}
                onChangeText={(text) => handleAnswerChange('question2', text)}
                placeholder="Who truly matters most to you?"
                placeholderTextColor="#666"
                multiline
              />
            </View>

            <View style={styles.questionBlock}>
              <Text style={styles.questionNumber}>QUESTION #3</Text>
              <Text style={styles.questionText}>HOW DO YOU MEASURE A MAN'S GRIT?</Text>
              <TextInput
                style={styles.answerInput}
                value={answers.question3}
                onChangeText={(text) => handleAnswerChange('question3', text)}
                placeholder="What defines true resilience?"
                placeholderTextColor="#666"
                multiline
              />
            </View>

            <TouchableOpacity style={styles.saveButton} onPress={saveAnswers}>
              <Text style={styles.saveButtonText}>LOCK IN ANSWERS</Text>
            </TouchableOpacity>
          </View>
        );
      case 'worth-tracker':
        return <SelfWorthTracker />;
      case 'journal':
        return <GrowthJournal />;
      default:
        return (
          <PersonalityForm 
            onSubmit={handlePersonalityUpdate} 
            initialData={personalityData} 
          />
        );
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <AIAvatar mood={aiMood} size={60} />
        <View style={styles.headerText}>
          <Text style={styles.title}>SELF MASTERY</Text>
          <Text style={styles.subtitle}>
            {activeView === 'questions' 
              ? 'FOUNDATIONAL QUESTIONS'
              : activeView === 'personality' 
              ? (totalTraits > 0 ? `${totalTraits} TRAITS MAPPED` : 'MAP YOUR PERSONALITY TRAITS')
              : activeView === 'journal'
              ? 'WEEKLY GROWTH TRACKING'
              : 'TRACK YOUR GROWTH AND ACHIEVEMENTS'
            }
          </Text>
        </View>
      </View>

      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tab, activeView === 'questions' && styles.activeTab]}
          onPress={() => setActiveView('questions')}
        >
          <Text style={[styles.tabText, activeView === 'questions' && styles.activeTabText]}>
            QUESTIONS
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeView === 'personality' && styles.activeTab]}
          onPress={() => setActiveView('personality')}
        >
          <Text style={[styles.tabText, activeView === 'personality' && styles.activeTabText]}>
            PERSONALITY
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeView === 'worth-tracker' && styles.activeTab]}
          onPress={() => setActiveView('worth-tracker')}
        >
          <Text style={[styles.tabText, activeView === 'worth-tracker' && styles.activeTabText]}>
            WORTH
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeView === 'journal' && styles.activeTab]}
          onPress={() => setActiveView('journal')}
        >
          <Text style={[styles.tabText, activeView === 'journal' && styles.activeTabText]}>
            JOURNAL
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {renderContent()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#1a1a1a',
    borderBottomWidth: 2,
    borderBottomColor: '#ff6b35',
  },
  headerText: {
    marginLeft: 16,
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ff6b35',
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 12,
    color: '#ccc',
    marginTop: 4,
    letterSpacing: 1,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#1a1a1a',
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: '#ff6b35',
  },
  tabText: {
    fontSize: 11,
    color: '#888',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  activeTabText: {
    color: '#ff6b35',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  questionsContainer: {
    paddingBottom: 40,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ff6b35',
    textAlign: 'center',
    marginBottom: 8,
    letterSpacing: 2,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#ccc',
    textAlign: 'center',
    marginBottom: 32,
    letterSpacing: 1,
  },
  questionBlock: {
    backgroundColor: '#1a1a1a',
    padding: 20,
    marginBottom: 24,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  questionNumber: {
    fontSize: 12,
    color: '#ff6b35',
    fontWeight: 'bold',
    marginBottom: 8,
    letterSpacing: 1,
  },
  questionText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 16,
    letterSpacing: 1,
  },
  answerInput: {
    backgroundColor: '#0a0a0a',
    color: '#fff',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333',
    fontSize: 16,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  saveButton: {
    backgroundColor: '#ff6b35',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  saveButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
});