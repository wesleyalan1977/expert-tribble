import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { AvatarConfig } from './AvatarCustomizer';

interface AvatarPreviewProps {
  avatar: AvatarConfig;
  size?: number;
}

export default function AvatarPreview({ avatar, size = 120 }: AvatarPreviewProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your AI Twin Avatar</Text>
      <View
        style={[
          styles.avatarContainer,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor: avatar.background,
          },
        ]}
      >
        <View style={styles.avatarContent}>
          <Text style={[styles.accessory, { fontSize: size * 0.15 }]}>
            {avatar.accessory}
          </Text>
          <Text style={[styles.face, { fontSize: size * 0.3 }]}>
            {avatar.face}
          </Text>
          <Text style={[styles.body, { fontSize: size * 0.2 }]}>
            {avatar.body}
          </Text>
        </View>
      </View>
      <View style={styles.personalityBadge}>
        <Text style={styles.personalityText}>{avatar.personality}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 15,
  },
  avatarContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
    marginBottom: 15,
  },
  avatarContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  accessory: {
    position: 'absolute',
    top: -10,
    right: -5,
  },
  face: {
    marginBottom: 5,
  },
  body: {
    opacity: 0.8,
  },
  personalityBadge: {
    backgroundColor: '#8b5cf6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
  },
  personalityText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});