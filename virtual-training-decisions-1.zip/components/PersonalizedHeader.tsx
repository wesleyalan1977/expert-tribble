import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { PersonalizationData } from './PersonalizationPanel';

interface PersonalizedHeaderProps {
  personalization: PersonalizationData;
  onEditPress: () => void;
}

export default function PersonalizedHeader({ personalization, onEditPress }: PersonalizedHeaderProps) {
  const getThemeColors = () => {
    switch (personalization.theme) {
      case 'strength':
        return { primary: '#1a1a1a', accent: '#ff6b35', secondary: '#2d2d2d' };
      case 'power':
        return { primary: '#0f172a', accent: '#3b82f6', secondary: '#1e293b' };
      case 'leadership':
        return { primary: '#18181b', accent: '#eab308', secondary: '#27272a' };
      case 'warrior':
        return { primary: '#7f1d1d', accent: '#fbbf24', secondary: '#991b1b' };
      default:
        return { primary: '#1a1a1a', accent: '#ff6b35', secondary: '#2d2d2d' };
    }
  };

  const colors = getThemeColors();

  return (
    <View style={[styles.header, { backgroundColor: colors.primary }]}>
      <View style={styles.metalFrame}>
        <View style={[styles.frameAccent, { backgroundColor: colors.accent }]} />
      </View>
      
      <View style={styles.headerContent}>
        <View style={styles.titleSection}>
          <Text style={styles.title}>{personalization.bookTitle}</Text>
          <Text style={styles.subtitle}>{personalization.bookSubtitle}</Text>
          <Text style={styles.author}>BY {personalization.authorName.toUpperCase()}</Text>
        </View>
        
        <TouchableOpacity style={[styles.editButton, { backgroundColor: colors.secondary }]} onPress={onEditPress}>
          <Text style={styles.editButtonText}>⚙️</Text>
        </TouchableOpacity>
      </View>
      
      <View style={[styles.quoteSection, { borderTopColor: colors.accent }]}>
        <Text style={[styles.quote, { color: colors.accent }]}>'{personalization.personalQuote}'</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    position: 'relative',
  },
  metalFrame: {
    position: 'absolute',
    left: 0,
    top: 60,
    bottom: 0,
    width: 12,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    borderRightWidth: 2,
    borderRightColor: '#555',
  },
  frameAccent: {
    width: 6,
    height: 60,
    borderRadius: 3,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginLeft: 20,
  },
  titleSection: {
    flex: 1,
  },
  title: {
    fontSize: 26,
    fontWeight: '900',
    color: 'white',
    marginBottom: 4,
    letterSpacing: 1,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    marginBottom: 8,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  author: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.7)',
    fontWeight: '700',
    letterSpacing: 1.5,
  },
  editButton: {
    borderRadius: 8,
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#555',
  },
  editButtonText: {
    fontSize: 18,
  },
  quoteSection: {
    marginTop: 16,
    marginLeft: 20,
    paddingTop: 16,
    borderTopWidth: 2,
  },
  quote: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
});