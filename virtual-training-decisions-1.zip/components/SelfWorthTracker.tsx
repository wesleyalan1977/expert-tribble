import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

interface Achievement {
  id: string;
  title: string;
  description: string;
  date: string;
  category: 'personal' | 'professional' | 'relationships' | 'growth';
}

const SAMPLE_ACHIEVEMENTS: Achievement[] = [
  {
    id: '1',
    title: 'SET A BOUNDARY',
    description: 'Refused overtime to protect personal time',
    date: 'TODAY',
    category: 'personal'
  },
  {
    id: '2',
    title: 'SPOKE WITH AUTHORITY',
    description: 'Shared ideas confidently despite nervousness',
    date: 'YESTERDAY',
    category: 'professional'
  },
  {
    id: '3',
    title: 'PRACTICED SELF-COMPASSION',
    description: 'Treated myself kindly after making a mistake',
    date: '2 DAYS AGO',
    category: 'growth'
  }
];

export default function SelfWorthTracker() {
  const [achievements, setAchievements] = useState<Achievement[]>(SAMPLE_ACHIEVEMENTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const addQuickAchievement = (title: string, category: Achievement['category']) => {
    const newAchievement: Achievement = {
      id: Date.now().toString(),
      title,
      description: 'Quick win logged',
      date: 'JUST NOW',
      category
    };
    setAchievements(prev => [newAchievement, ...prev]);
  };

  const filteredAchievements = selectedCategory === 'all' 
    ? achievements 
    : achievements.filter(a => a.category === selectedCategory);

  const quickWins = [
    { title: 'STOOD MY GROUND', category: 'personal' as const },
    { title: 'CRUSHED A GOAL', category: 'professional' as const },
    { title: 'HELPED SOMEONE', category: 'relationships' as const },
    { title: 'LEARNED SOMETHING', category: 'growth' as const },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>WORTH TRACKER</Text>
      <Text style={styles.subtitle}>
        Document your victories, no matter how small
      </Text>
      
      <View style={styles.stats}>
        <Text style={styles.statsText}>
          {achievements.length} ACHIEVEMENTS LOGGED
        </Text>
      </View>

      <Text style={styles.sectionTitle}>QUICK WINS</Text>
      <View style={styles.quickWins}>
        {quickWins.map((win, index) => (
          <TouchableOpacity
            key={index}
            style={styles.quickWinButton}
            onPress={() => addQuickAchievement(win.title, win.category)}
          >
            <Text style={styles.quickWinText}>+ {win.title}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.categoryButtons}>
        {['all', 'personal', 'professional', 'relationships', 'growth'].map(category => (
          <TouchableOpacity
            key={category}
            style={[
              styles.categoryButton,
              selectedCategory === category && styles.activeCategoryButton
            ]}
            onPress={() => setSelectedCategory(category)}
          >
            <Text style={[
              styles.categoryButtonText,
              selectedCategory === category && styles.activeCategoryButtonText
            ]}>
              {category.toUpperCase()}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.achievementsList} showsVerticalScrollIndicator={false}>
        {filteredAchievements.map(achievement => (
          <View key={achievement.id} style={styles.achievementCard}>
            <View style={styles.achievementHeader}>
              <Text style={styles.achievementTitle}>{achievement.title}</Text>
              <Text style={styles.achievementDate}>{achievement.date}</Text>
            </View>
            <Text style={styles.achievementDescription}>
              {achievement.description}
            </Text>
            <View style={styles.categoryTag}>
              <Text style={styles.categoryTagText}>{achievement.category.toUpperCase()}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 40,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ff6b35',
    textAlign: 'center',
    marginBottom: 8,
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 14,
    color: '#ccc',
    textAlign: 'center',
    marginBottom: 24,
    letterSpacing: 1,
  },
  stats: {
    backgroundColor: '#1a1a1a',
    padding: 16,
    borderRadius: 8,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#333',
  },
  statsText: {
    textAlign: 'center',
    color: '#ff6b35',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ff6b35',
    marginBottom: 16,
    letterSpacing: 1,
  },
  quickWins: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 24,
  },
  quickWinButton: {
    backgroundColor: '#ff6b35',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },
  quickWinText: {
    color: '#000',
    fontSize: 12,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  categoryButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 20,
  },
  categoryButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
  },
  activeCategoryButton: {
    backgroundColor: '#ff6b35',
    borderColor: '#ff6b35',
  },
  categoryButtonText: {
    fontSize: 11,
    color: '#ccc',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  activeCategoryButtonText: {
    color: '#000',
  },
  achievementsList: {
    flex: 1,
  },
  achievementCard: {
    padding: 16,
    borderRadius: 8,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
    marginBottom: 16,
  },
  achievementHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  achievementTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
    flex: 1,
    letterSpacing: 1,
  },
  achievementDate: {
    fontSize: 12,
    color: '#ff6b35',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  achievementDescription: {
    fontSize: 14,
    color: '#ccc',
    marginBottom: 12,
    letterSpacing: 0.5,
  },
  categoryTag: {
    alignSelf: 'flex-start',
    backgroundColor: '#333',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#555',
  },
  categoryTagText: {
    fontSize: 10,
    color: '#ff6b35',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
});