import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { supabase } from '../app/lib/supabase';

export function PurchaseManager() {
  const [loading, setLoading] = useState(false);
  const [purchased, setPurchased] = useState(false);

  const handlePurchase = async () => {
    setLoading(true);
    try {
      Alert.alert(
        'Purchase App',
        'Buy the full app for $2.99 and unlock all features permanently.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Buy Now', onPress: () => processPurchase() }
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to process purchase');
    } finally {
      setLoading(false);
    }
  };

  const processPurchase = async () => {
    // Here you would integrate with your payment processor
    // For now, we'll simulate a successful purchase
    setPurchased(true);
    Alert.alert('Success', 'Welcome to the full app! Your royal journey begins.');
  };

  if (purchased) {
    return (
      <View style={styles.container}>
        <View style={styles.successContainer}>
          <Text style={styles.successIcon}>👑</Text>
          <Text style={styles.successTitle}>WELCOME, ROYALTY!</Text>
          <Text style={styles.successMessage}>
            You now have full access to all features.
            Your journey to self-mastery begins now.
          </Text>
          <View style={styles.featuresList}>
            <Text style={styles.featureItem}>✓ Complete self-assessment tools</Text>
            <Text style={styles.featureItem}>✓ Advanced growth tracking</Text>
            <Text style={styles.featureItem}>✓ AI-powered insights</Text>
            <Text style={styles.featureItem}>✓ Unlimited progress tracking</Text>
            <Text style={styles.featureItem}>✓ All future updates included</Text>
          </View>
        </View>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>👑 UNLOCK FULL POWER</Text>
        <Text style={styles.subtitle}>One-time purchase, lifetime access</Text>
      </View>

      <View style={styles.purchaseCard}>
        <View style={styles.priceContainer}>
          <Text style={styles.currency}>$</Text>
          <Text style={styles.price}>2.99</Text>
          <Text style={styles.priceLabel}>one-time</Text>
        </View>
        
        <Text style={styles.valueText}>🔥 INCREDIBLE VALUE</Text>
        
        <View style={styles.featuresContainer}>
          <Text style={styles.featuresTitle}>What You Get:</Text>
          <View style={styles.featureRow}>
            <Text style={styles.checkmark}>✓</Text>
            <Text style={styles.featureText}>Complete self-assessment suite</Text>
          </View>
          <View style={styles.featureRow}>
            <Text style={styles.checkmark}>✓</Text>
            <Text style={styles.featureText}>Advanced progress tracking</Text>
          </View>
          <View style={styles.featureRow}>
            <Text style={styles.checkmark}>✓</Text>
            <Text style={styles.featureText}>AI-powered insights & coaching</Text>
          </View>
          <View style={styles.featureRow}>
            <Text style={styles.checkmark}>✓</Text>
            <Text style={styles.featureText}>Unlimited growth journal</Text>
          </View>
          <View style={styles.featureRow}>
            <Text style={styles.checkmark}>✓</Text>
            <Text style={styles.featureText}>All future updates FREE</Text>
          </View>
        </View>
        
        <TouchableOpacity
          style={styles.purchaseButton}
          onPress={handlePurchase}
          disabled={loading}
        >
          <Text style={styles.purchaseText}>
            {loading ? 'PROCESSING...' : 'BUY NOW - $2.99'}
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>⚠️ No subscriptions. No hidden fees.</Text>
        <Text style={styles.footerSubtext}>Pay once, own forever. Your growth is an investment.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  header: {
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#1a1a1a',
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: '#ffd700',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffd700',
    textAlign: 'center',
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 16,
    color: '#ff6b35',
    textAlign: 'center',
    marginTop: 5,
    fontStyle: 'italic',
  },
  purchaseCard: {
    margin: 20,
    backgroundColor: '#1a1a1a',
    borderRadius: 15,
    padding: 30,
    borderWidth: 2,
    borderColor: '#ffd700',
    alignItems: 'center',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 10,
  },
  currency: {
    fontSize: 24,
    color: '#ffd700',
    fontWeight: 'bold',
  },
  price: {
    fontSize: 48,
    color: '#ffd700',
    fontWeight: 'bold',
  },
  priceLabel: {
    fontSize: 16,
    color: '#999',
    marginLeft: 8,
  },
  valueText: {
    fontSize: 18,
    color: '#ff6b35',
    fontWeight: 'bold',
    marginBottom: 20,
  },
  featuresContainer: {
    width: '100%',
    marginBottom: 30,
  },
  featuresTitle: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  checkmark: {
    color: '#4ade80',
    fontSize: 16,
    marginRight: 10,
  },
  featureText: {
    color: '#fff',
    fontSize: 14,
    flex: 1,
  },
  purchaseButton: {
    backgroundColor: '#ffd700',
    paddingVertical: 18,
    paddingHorizontal: 40,
    borderRadius: 10,
    alignItems: 'center',
    width: '100%',
  },
  purchaseText: {
    color: '#000',
    fontSize: 18,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  footer: {
    padding: 20,
    alignItems: 'center',
  },
  footerText: {
    color: '#ff6b35',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: 'bold',
  },
  footerSubtext: {
    color: '#999',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 5,
  },
  successContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  successIcon: {
    fontSize: 80,
    marginBottom: 20,
  },
  successTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffd700',
    textAlign: 'center',
    marginBottom: 20,
    letterSpacing: 2,
  },
  successMessage: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 24,
  },
  featuresList: {
    width: '100%',
  },
  featureItem: {
    fontSize: 16,
    color: '#4ade80',
    marginBottom: 10,
    textAlign: 'center',
  },
});