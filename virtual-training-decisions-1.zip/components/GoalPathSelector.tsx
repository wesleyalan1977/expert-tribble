import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import PathCard from './PathCard';

interface Goal {
  id: string;
  title: string;
  easyPath: {
    title: string;
    description: string;
    icon: string;
  };
  hardPath: {
    title: string;
    description: string;
    icon: string;
  };
}

interface GoalPathSelectorProps {
  onPathSelected: (goalId: string, pathType: 'easy' | 'hard') => void;
}

const goals: Goal[] = [
  {
    id: 'confidence',
    title: 'Building Confidence',
    easyPath: {
      title: 'Fake It Till You Make It',
      description: 'Put on a confident facade, follow popular advice, seek external validation through likes and approval from others.',
      icon: '🎭'
    },
    hardPath: {
      title: 'Self-Reliant Confidence',
      description: 'Build genuine self-worth through discipline, facing fears, developing skills, and earning your own respect through consistent action.',
      icon: '⚔️'
    }
  },
  {
    id: 'success',
    title: 'Achieving Success',
    easyPath: {
      title: 'Quick Wins & Shortcuts',
      description: 'Look for hacks, get-rich-quick schemes, rely on others to carry you, take credit for team efforts.',
      icon: '🎲'
    },
    hardPath: {
      title: 'Earned Excellence',
      description: 'Master your craft through deliberate practice, take full responsibility, build systems, create value for others.',
      icon: '👑'
    }
  },
  {
    id: 'relationships',
    title: 'Better Relationships',
    easyPath: {
      title: 'People Pleasing',
      description: 'Say yes to everything, avoid conflict, change yourself to fit in, seek approval by being agreeable.',
      icon: '🤝'
    },
    hardPath: {
      title: 'Authentic Boundaries',
      description: 'Set clear boundaries, communicate honestly, attract the right people by being genuinely yourself.',
      icon: '🛡️'
    }
  }
];

export default function GoalPathSelector({ onPathSelected }: GoalPathSelectorProps) {
  const [selectedPaths, setSelectedPaths] = useState<{[key: string]: 'easy' | 'hard' | null}>({});

  const handlePathSelect = (goalId: string, pathType: 'easy' | 'hard') => {
    setSelectedPaths(prev => ({ ...prev, [goalId]: pathType }));
    onPathSelected(goalId, pathType);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>⚡ CHOOSE YOUR PATH ⚡</Text>
      <Text style={styles.subtitle}>
        Every goal has two paths. Most take the easy road. Kings take the hard one.
      </Text>

      {goals.map((goal) => (
        <View key={goal.id} style={styles.goalSection}>
          <Text style={styles.goalTitle}>{goal.title}</Text>
          
          <PathCard
            title={goal.easyPath.title}
            description={goal.easyPath.description}
            icon={goal.easyPath.icon}
            type="easy"
            selected={selectedPaths[goal.id] === 'easy'}
            onPress={() => handlePathSelect(goal.id, 'easy')}
          />
          
          <PathCard
            title={goal.hardPath.title}
            description={goal.hardPath.description}
            icon={goal.hardPath.icon}
            type="hard"
            selected={selectedPaths[goal.id] === 'hard'}
            onPress={() => handlePathSelect(goal.id, 'hard')}
          />
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#f59e0b',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#d1d5db',
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
  },
  goalSection: {
    marginBottom: 32,
  },
  goalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#f59e0b',
    marginBottom: 16,
    textAlign: 'center',
  },
});