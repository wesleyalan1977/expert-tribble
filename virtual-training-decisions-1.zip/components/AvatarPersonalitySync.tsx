import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { AvatarConfig } from './AvatarCustomizer';

interface AvatarPersonalitySyncProps {
  avatar: AvatarConfig;
  onSyncComplete: (syncedAvatar: AvatarConfig) => void;
}

const PERSONALITY_MAPPINGS = {
  Confident: { face: '💪', body: '🏃', accessory: '👑', background: '#ef4444' },
  Wise: { face: '🤔', body: '🧠', accessory: '🔮', background: '#8b5cf6' },
  Energetic: { face: '⚡', body: '💃', accessory: '🌟', background: '#f59e0b' },
  Calm: { face: '🧘', body: '🌸', accessory: '🌺', background: '#06b6d4' },
  Creative: { face: '🦋', body: '🌈', accessory: '🎨', background: '#ec4899' },
  Bold: { face: '🔥', body: '🤸', accessory: '💎', background: '#f97316' },
  Gentle: { face: '🌸', body: '🤗', accessory: '🎀', background: '#84cc16' },
  Fierce: { face: '😤', body: '⚔️', accessory: '⚡', background: '#dc2626' },
  Playful: { face: '😄', body: '🎪', accessory: '🎭', background: '#f43f5e' },
  Focused: { face: '🎯', body: '🧘', accessory: '⭐', background: '#6366f1' }
};

export default function AvatarPersonalitySync({ avatar, onSyncComplete }: AvatarPersonalitySyncProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const syncWithPersonality = () => {
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const mapping = PERSONALITY_MAPPINGS[avatar.personality as keyof typeof PERSONALITY_MAPPINGS];
      if (mapping) {
        const syncedAvatar: AvatarConfig = {
          ...avatar,
          ...mapping
        };
        onSyncComplete(syncedAvatar);
        Alert.alert(
          'Sync Complete!',
          `Your avatar has been updated to match your ${avatar.personality} personality traits.`
        );
      }
      setIsAnalyzing(false);
    }, 2000);
  };

  const getPersonalityDescription = () => {
    const descriptions = {
      Confident: 'Strong, assertive, and self-assured',
      Wise: 'Thoughtful, knowledgeable, and insightful',
      Energetic: 'Dynamic, vibrant, and full of life',
      Calm: 'Peaceful, centered, and serene',
      Creative: 'Imaginative, artistic, and innovative',
      Bold: 'Brave, daring, and fearless',
      Gentle: 'Kind, soft, and nurturing',
      Fierce: 'Intense, powerful, and determined',
      Playful: 'Fun-loving, joyful, and spontaneous',
      Focused: 'Concentrated, goal-oriented, and precise'
    };
    return descriptions[avatar.personality as keyof typeof descriptions] || 'Unique and special';
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Personality Sync</Text>
      <View style={styles.personalityCard}>
        <Text style={styles.personalityName}>{avatar.personality}</Text>
        <Text style={styles.personalityDescription}>{getPersonalityDescription()}</Text>
      </View>
      
      <TouchableOpacity 
        style={[styles.syncButton, isAnalyzing && styles.syncButtonDisabled]}
        onPress={syncWithPersonality}
        disabled={isAnalyzing}
      >
        <Text style={styles.syncButtonText}>
          {isAnalyzing ? '🔄 Analyzing...' : '✨ Sync Avatar with Personality'}
        </Text>
      </TouchableOpacity>
      
      <Text style={styles.description}>
        This will automatically adjust your avatar's appearance to match your personality traits.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: 'white',
    borderRadius: 15,
    margin: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginBottom: 15,
  },
  personalityCard: {
    backgroundColor: '#f3f4f6',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  personalityName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#8b5cf6',
    textAlign: 'center',
  },
  personalityDescription: {
    fontSize: 14,
    color: '#6b7280',
    textAlign: 'center',
    marginTop: 5,
  },
  syncButton: {
    backgroundColor: '#8b5cf6',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25,
    marginBottom: 15,
  },
  syncButtonDisabled: {
    backgroundColor: '#9ca3af',
  },
  syncButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  description: {
    fontSize: 12,
    color: '#6b7280',
    textAlign: 'center',
    lineHeight: 16,
  },
});