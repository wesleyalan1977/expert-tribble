import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

interface GoalSelectorProps {
  goals: string[];
  onGoalSelected: (goal: string) => void;
  detectedTraits: string[];
}

export default function GoalSelector({ goals, onGoalSelected, detectedTraits }: GoalSelectorProps) {
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);

  const defaultGoals = [
    {
      id: '1',
      title: 'Emotional Mastery',
      description: 'Develop deep self-awareness and emotional intelligence.',
      icon: '🧠'
    },
    {
      id: '2', 
      title: 'Consistent Excellence',
      description: 'Build unshakeable habits and discipline.',
      icon: '💼'
    },
    {
      id: '3',
      title: 'Authentic Connection', 
      description: 'Cultivate meaningful relationships and trust.',
      icon: '🤝'
    }
  ];

  const handleGoalSelect = (goal: any) => {
    setSelectedGoal(goal.id);
    onGoalSelected(goal.title);
  };

  if (goals.length === 0 && detectedTraits.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Character Development Paths</Text>
        <Text style={styles.subtitle}>Continue our conversation to discover your personalized growth paths.</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Your Character Development Paths</Text>
      <Text style={styles.subtitle}>Choose your path to become who you want others to see:</Text>
      
      {detectedTraits.length > 0 && (
        <View style={styles.traitsContainer}>
          <Text style={styles.traitsTitle}>Detected Traits:</Text>
          {detectedTraits.map((trait, index) => (
            <View key={index} style={styles.trait}>
              <Text style={styles.traitText}>{trait}</Text>
            </View>
          ))}
        </View>
      )}

      <View style={styles.goalsContainer}>
        {defaultGoals.map((goal) => (
          <TouchableOpacity
            key={goal.id}
            style={[styles.goalCard, selectedGoal === goal.id && styles.selectedGoal]}
            onPress={() => handleGoalSelect(goal)}
          >
            <View style={styles.goalHeader}>
              <Text style={styles.goalIcon}>{goal.icon}</Text>
              <Text style={styles.goalTitle}>{goal.title}</Text>
            </View>
            <Text style={styles.goalDescription}>{goal.description}</Text>
            {selectedGoal === goal.id && (
              <View style={styles.selectedIndicator}>
                <Text style={styles.selectedText}>✓ Selected Path</Text>
              </View>
            )}
          </TouchableOpacity>
        ))}
      </View>

      {selectedGoal && (
        <View style={styles.nextStepsContainer}>
          <Text style={styles.nextStepsTitle}>Next Steps</Text>
          <Text style={styles.nextStepsText}>
            Great choice! Your AI twin will now help you make decisions aligned with this path.
          </Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#1f2937', marginBottom: 8 },
  subtitle: { fontSize: 16, color: '#6b7280', marginBottom: 24, lineHeight: 22 },
  traitsContainer: { marginBottom: 24, padding: 16, backgroundColor: '#f3f4f6', borderRadius: 12 },
  traitsTitle: { fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 12 },
  trait: { backgroundColor: '#6366f1', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, marginRight: 8, marginBottom: 8, alignSelf: 'flex-start' },
  traitText: { color: 'white', fontSize: 14, fontWeight: '500' },
  goalsContainer: { gap: 16 },
  goalCard: { backgroundColor: 'white', borderRadius: 12, padding: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  selectedGoal: { borderWidth: 2, borderColor: '#6366f1' },
  goalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  goalIcon: { fontSize: 24, marginRight: 12 },
  goalTitle: { fontSize: 18, fontWeight: 'bold', color: '#1f2937' },
  goalDescription: { fontSize: 16, color: '#4b5563', lineHeight: 22 },
  selectedIndicator: { marginTop: 12, padding: 8, backgroundColor: '#dcfce7', borderRadius: 8 },
  selectedText: { color: '#166534', fontWeight: '600', textAlign: 'center' },
  nextStepsContainer: { marginTop: 24, padding: 16, backgroundColor: '#eff6ff', borderRadius: 12 },
  nextStepsTitle: { fontSize: 18, fontWeight: 'bold', color: '#1e40af', marginBottom: 8 },
  nextStepsText: { fontSize: 16, color: '#1e40af', lineHeight: 22 }
});