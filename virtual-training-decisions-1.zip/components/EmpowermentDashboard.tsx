import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

interface EmpowermentDashboardProps {
  onSelfRespectAction: () => void;
  onBoundaryAction: () => void;
  onValueAction: () => void;
}

export default function EmpowermentDashboard({
  onSelfRespectAction,
  onBoundaryAction,
  onValueAction
}: EmpowermentDashboardProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>COMMAND CENTER</Text>
      <Text style={styles.subtitle}>
        STRENGTH COMES FROM WITHIN - RESPECT IS EARNED
      </Text>
      
      <View style={styles.actionGrid}>
        <TouchableOpacity 
          style={[styles.actionCard, styles.selfRespectCard]}
          onPress={onSelfRespectAction}
        >
          <Text style={styles.cardIcon}>⚡</Text>
          <Text style={styles.cardTitle}>BUILD STRENGTH</Text>
          <Text style={styles.cardDesc}>FORGE YOUR INNER FOUNDATION</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionCard, styles.boundaryCard]}
          onPress={onBoundaryAction}
        >
          <Text style={styles.cardIcon}>🛡️</Text>
          <Text style={styles.cardTitle}>SET BOUNDARIES</Text>
          <Text style={styles.cardDesc}>DEFEND YOUR TERRITORY</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionCard, styles.valueCard]}
          onPress={onValueAction}
        >
          <Text style={styles.cardIcon}>👑</Text>
          <Text style={styles.cardTitle}>CLAIM POWER</Text>
          <Text style={styles.cardDesc}>RECOGNIZE YOUR DOMINANCE</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.statsSection}>
        <Text style={styles.statsTitle}>TODAY'S MISSION</Text>
        <View style={styles.statRow}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>100%</Text>
            <Text style={styles.statLabel}>COMMITMENT</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>ZERO</Text>
            <Text style={styles.statLabel}>EXCUSES</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>MAX</Text>
            <Text style={styles.statLabel}>EFFORT</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#1a1a1a',
    borderRadius: 8,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#333',
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 8,
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 14,
    color: '#ff6b35',
    textAlign: 'center',
    marginBottom: 24,
    fontWeight: '600',
    letterSpacing: 1,
  },
  actionGrid: {
    gap: 12,
    marginBottom: 24,
  },
  actionCard: {
    padding: 20,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 2,
  },
  selfRespectCard: {
    backgroundColor: '#2d1b00',
    borderColor: '#ff6b35',
  },
  boundaryCard: {
    backgroundColor: '#001a2d',
    borderColor: '#3b82f6',
  },
  valueCard: {
    backgroundColor: '#1a0d2d',
    borderColor: '#eab308',
  },
  cardIcon: {
    fontSize: 36,
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#ffffff',
    marginBottom: 8,
    letterSpacing: 1.5,
  },
  cardDesc: {
    fontSize: 12,
    color: '#cccccc',
    textAlign: 'center',
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  statsSection: {
    borderTopWidth: 2,
    borderTopColor: '#333',
    paddingTop: 16,
  },
  statsTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#ff6b35',
    textAlign: 'center',
    marginBottom: 12,
    letterSpacing: 1,
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 20,
    fontWeight: '900',
    color: '#ffffff',
    letterSpacing: 1,
  },
  statLabel: {
    fontSize: 10,
    color: '#cccccc',
    fontWeight: '600',
    letterSpacing: 1,
    marginTop: 4,
  },
});