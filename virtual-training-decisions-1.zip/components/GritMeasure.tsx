import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useUserActivity } from '../hooks/useUserActivity';

export function GritMeasure() {
  const [showModal, setShowModal] = useState(false);
  const { continuousDays, isEligible } = useUserActivity();

  const progress = Math.min(continuousDays / 180, 1);
  const remainingDays = Math.max(180 - continuousDays, 0);

  const handlePress = () => {
    if (isEligible) {
      setShowModal(true);
    }
  };

  return (
    <>
      <TouchableOpacity 
        style={[styles.menuCard, !isEligible && styles.lockedCard]} 
        onPress={handlePress}
      >
        <LinearGradient
          colors={isEligible ? ['#2a2a2a', '#1a1a1a'] : ['#1a1a1a', '#0a0a0a']}
          style={styles.menuCardGradient}
        >
          <Text style={styles.menuIcon}>{isEligible ? '⚡' : '🔒'}</Text>
          <Text style={styles.menuLabel}>GRIT WISDOM</Text>
          <Text style={styles.menuDesc}>Ancient Knowledge</Text>
          <View style={[styles.lockBadge, isEligible && styles.unlockedBadge]}>
            <Text style={styles.lockText}>
              {isEligible ? 'UNLOCKED' : `${continuousDays}/180`}
            </Text>
          </View>
        </LinearGradient>
      </TouchableOpacity>

      <Modal visible={showModal} animationType="slide">
        <LinearGradient
          colors={['#0a0a0a', '#1a1a1a', '#0a0a0a']}
          style={styles.container}
        >
          <View style={styles.header}>
            <Text style={styles.title}>⚡ GRIT WISDOM ⚡</Text>
            <TouchableOpacity 
              style={styles.closeButton} 
              onPress={() => setShowModal(false)}
            >
              <Text style={styles.closeText}>✕</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.content}>
            <View style={styles.questionSection}>
              <Text style={styles.question}>
                "How do you measure a man's grit?"
              </Text>
            </View>

            {!isEligible ? (
              <View style={styles.lockedSection}>
                <Text style={styles.lockIcon}>🔐</Text>
                <Text style={styles.lockedText}>WISDOM LOCKED</Text>
                <Text style={styles.unlockHint}>
                  Only those who show dedication for 180 continuous days may access this ancient wisdom.
                </Text>
                
                <View style={styles.progressSection}>
                  <Text style={styles.progressText}>
                    Progress: {continuousDays}/180 Days
                  </Text>
                  <View style={styles.progressBar}>
                    <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
                  </View>
                  <Text style={styles.remainingText}>
                    {remainingDays} days remaining
                  </Text>
                </View>
              </View>
            ) : (
              <View style={styles.answerSection}>
                <Text style={styles.answerTitle}>🏆 THE ANSWER 🏆</Text>
                
                <LinearGradient
                  colors={['#2a2a1a', '#1a1a1a']}
                  style={styles.answerBox}
                >
                  <Text style={styles.answer}>
                    "Open the door to his heart's desires and show him the mountain he must face to obtain it and measure how far he makes it before he gives up."
                  </Text>
                  <Text style={styles.signature}>- Melchizedek</Text>
                </LinearGradient>

                <LinearGradient
                  colors={['#0a2a0a', '#1a1a1a']}
                  style={styles.congratsBox}
                >
                  <Text style={styles.congratsText}>
                    🎉 Congratulations! You have proven your dedication through 180 days of continuous growth. 🎉
                  </Text>
                </LinearGradient>
              </View>
            )}
          </View>
        </LinearGradient>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  menuCard: {
    width: '48%',
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#ff6b35',
    shadowColor: '#ff6b35',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  lockedCard: {
    borderColor: '#666',
    opacity: 0.8,
  },
  menuCardGradient: {
    padding: 20,
    borderRadius: 14,
    alignItems: 'center',
    position: 'relative',
  },
  menuIcon: {
    fontSize: 32,
    marginBottom: 10,
  },
  menuLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 5,
    letterSpacing: 0.5,
  },
  menuDesc: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
  },
  lockBadge: {
    position: 'absolute',
    top: 5,
    right: 5,
    backgroundColor: '#666',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  unlockedBadge: {
    backgroundColor: '#4CAF50',
  },
  lockText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
    backgroundColor: '#1a1a1a',
    borderBottomWidth: 2,
    borderBottomColor: '#ffd700',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffd700',
    textAlign: 'center',
    flex: 1,
    textShadowColor: '#ffd700',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },
  closeButton: {
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeText: {
    fontSize: 20,
    color: '#ffffff',
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  questionSection: {
    marginBottom: 30,
    padding: 20,
    backgroundColor: '#1a1a1a',
    borderRadius: 15,
    borderWidth: 2,
    borderColor: '#ffd700',
    shadowColor: '#ffd700',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  question: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffd700',
    textAlign: 'center',
    letterSpacing: 1,
  },
  lockedSection: {
    alignItems: 'center',
    padding: 40,
    backgroundColor: '#1a1a1a',
    borderRadius: 15,
    borderWidth: 2,
    borderColor: '#666',
  },
  lockIcon: {
    fontSize: 60,
    marginBottom: 20,
  },
  lockedText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 10,
  },
  unlockHint: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
    marginBottom: 20,
  },
  progressSection: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 30,
  },
  progressText: {
    fontSize: 18,
    color: '#ffd700',
    fontWeight: 'bold',
    marginBottom: 10,
  },
  progressBar: {
    width: '100%',
    height: 8,
    backgroundColor: '#333',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 10,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#ff6b35',
  },
  remainingText: {
    fontSize: 14,
    color: '#999',
  },
  answerSection: {
    gap: 20,
  },
  answerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffd700',
    textAlign: 'center',
    marginBottom: 10,
    textShadowColor: '#ffd700',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 5,
  },
  answerBox: {
    padding: 25,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: '#ffd700',
  },
  answer: {
    fontSize: 18,
    color: '#ffffff',
    lineHeight: 28,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  signature: {
    fontSize: 16,
    color: '#ff6b35',
    textAlign: 'right',
    fontWeight: 'bold',
    marginTop: 10,
  },
  congratsBox: {
    padding: 20,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#4CAF50',
  },
  congratsText: {
    fontSize: 16,
    color: '#4CAF50',
    textAlign: 'center',
    fontWeight: 'bold',
  },
});