import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

interface Affirmation {
  id: string;
  text: string;
  category: 'self-worth' | 'boundaries' | 'respect';
}

const AFFIRMATIONS: Affirmation[] = [
  { id: '1', text: 'I deserve respect in all my relationships', category: 'respect' },
  { id: '2', text: 'My boundaries are valid and important', category: 'boundaries' },
  { id: '3', text: 'I am worthy of love and kindness', category: 'self-worth' },
  { id: '4', text: 'I choose how others treat me by how I treat myself', category: 'respect' },
  { id: '5', text: 'My voice matters and deserves to be heard', category: 'boundaries' },
  { id: '6', text: 'I am complete and valuable as I am', category: 'self-worth' },
];

export default function SelfRespectBuilder() {
  const [selectedAffirmations, setSelectedAffirmations] = useState<string[]>([]);
  const [currentCategory, setCurrentCategory] = useState<string>('all');

  const toggleAffirmation = (id: string) => {
    setSelectedAffirmations(prev => 
      prev.includes(id) 
        ? prev.filter(affId => affId !== id)
        : [...prev, id]
    );
  };

  const filteredAffirmations = currentCategory === 'all' 
    ? AFFIRMATIONS 
    : AFFIRMATIONS.filter(aff => aff.category === currentCategory);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Build Your Self-Respect</Text>
      <Text style={styles.subtitle}>
        Choose affirmations that resonate with you
      </Text>
      
      <View style={styles.categoryButtons}>
        {['all', 'self-worth', 'boundaries', 'respect'].map(category => (
          <TouchableOpacity
            key={category}
            style={[
              styles.categoryButton,
              currentCategory === category && styles.activeCategoryButton
            ]}
            onPress={() => setCurrentCategory(category)}
          >
            <Text style={[
              styles.categoryButtonText,
              currentCategory === category && styles.activeCategoryButtonText
            ]}>
              {category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.affirmationsList}>
        {filteredAffirmations.map(affirmation => (
          <TouchableOpacity
            key={affirmation.id}
            style={[
              styles.affirmationCard,
              selectedAffirmations.includes(affirmation.id) && styles.selectedCard
            ]}
            onPress={() => toggleAffirmation(affirmation.id)}
          >
            <Text style={[
              styles.affirmationText,
              selectedAffirmations.includes(affirmation.id) && styles.selectedText
            ]}>
              {affirmation.text}
            </Text>
            {selectedAffirmations.includes(affirmation.id) && (
              <Text style={styles.checkmark}>✓</Text>
            )}
          </TouchableOpacity>
        ))}
      </ScrollView>
      
      <Text style={styles.footer}>
        {selectedAffirmations.length} affirmations selected
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 20,
  },
  categoryButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 20,
  },
  categoryButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: '#f3f4f6',
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  activeCategoryButton: {
    backgroundColor: '#3b82f6',
    borderColor: '#3b82f6',
  },
  categoryButtonText: {
    fontSize: 12,
    color: '#6b7280',
  },
  activeCategoryButtonText: {
    color: '#fff',
  },
  affirmationsList: {
    flex: 1,
  },
  affirmationCard: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#f9fafb',
    borderWidth: 1,
    borderColor: '#e5e7eb',
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  selectedCard: {
    backgroundColor: '#eff6ff',
    borderColor: '#3b82f6',
  },
  affirmationText: {
    fontSize: 16,
    color: '#1f2937',
    flex: 1,
  },
  selectedText: {
    color: '#1e40af',
    fontWeight: '500',
  },
  checkmark: {
    fontSize: 18,
    color: '#10b981',
    marginLeft: 8,
  },
  footer: {
    textAlign: 'center',
    color: '#6b7280',
    marginTop: 16,
  },
});