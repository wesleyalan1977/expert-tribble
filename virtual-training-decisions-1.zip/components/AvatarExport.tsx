import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, Share } from 'react-native';
import { AvatarConfig } from './AvatarCustomizer';
import AvatarPreview from './AvatarPreview';

interface AvatarExportProps {
  avatar: AvatarConfig;
}

export default function AvatarExport({ avatar }: AvatarExportProps) {
  const [isExporting, setIsExporting] = useState(false);

  const generateAvatarCode = () => {
    return JSON.stringify(avatar, null, 2);
  };

  const generateAvatarDescription = () => {
    return `My AI Twin Avatar:\n` +
           `Personality: ${avatar.personality}\n` +
           `Style: ${avatar.face} ${avatar.body} ${avatar.accessory}\n` +
           `Created with AI Twin Avatar Builder`;
  };

  const handleShare = async () => {
    try {
      const description = generateAvatarDescription();
      await Share.share({
        message: description,
        title: 'My AI Twin Avatar'
      });
    } catch (error) {
      Alert.alert('Error', 'Could not share avatar');
    }
  };

  const handleExportCode = () => {
    setIsExporting(true);
    const code = generateAvatarCode();
    
    setTimeout(() => {
      Alert.alert(
        'Avatar Code',
        'Avatar configuration copied! You can use this to recreate your avatar.',
        [
          {
            text: 'Copy Code',
            onPress: () => {
              // In a real app, you'd copy to clipboard
              console.log('Avatar code:', code);
            }
          },
          { text: 'OK' }
        ]
      );
      setIsExporting(false);
    }, 1000);
  };

  const handleSaveAsDefault = () => {
    Alert.alert(
      'Set as Default',
      'Make this your default AI Twin avatar?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Set Default',
          onPress: () => {
            // In a real app, you'd save to storage
            Alert.alert('Success', 'Avatar set as default!');
          }
        }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Export & Share</Text>
      
      <View style={styles.previewContainer}>
        <AvatarPreview avatar={avatar} size={100} />
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.shareButton} onPress={handleShare}>
          <Text style={styles.buttonText}>📱 Share Avatar</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.exportButton, isExporting && styles.buttonDisabled]} 
          onPress={handleExportCode}
          disabled={isExporting}
        >
          <Text style={styles.buttonText}>
            {isExporting ? '⏳ Exporting...' : '💾 Export Code'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.defaultButton} onPress={handleSaveAsDefault}>
          <Text style={styles.buttonText}>⭐ Set as Default</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.infoTitle}>Avatar Summary</Text>
        <Text style={styles.infoText}>Personality: {avatar.personality}</Text>
        <Text style={styles.infoText}>Expression: {avatar.face}</Text>
        <Text style={styles.infoText}>Style: {avatar.body}</Text>
        <Text style={styles.infoText}>Accessory: {avatar.accessory}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: 'white',
    borderRadius: 15,
    margin: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginBottom: 20,
  },
  previewContainer: {
    alignItems: 'center',
    marginBottom: 25,
  },
  buttonContainer: {
    gap: 12,
    marginBottom: 25,
  },
  shareButton: {
    backgroundColor: '#10b981',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25,
  },
  exportButton: {
    backgroundColor: '#8b5cf6',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25,
  },
  defaultButton: {
    backgroundColor: '#f59e0b',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25,
  },
  buttonDisabled: {
    backgroundColor: '#9ca3af',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  infoContainer: {
    backgroundColor: '#f9fafb',
    padding: 15,
    borderRadius: 10,
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 12,
    color: '#6b7280',
    marginBottom: 4,
  },
});