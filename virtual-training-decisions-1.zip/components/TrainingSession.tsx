import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import AIAvatar from './AIAvatar';

interface TrainingSessionProps {
  onSubmit: (scenario: string, userDecision: string) => void;
}

export default function TrainingSession({ onSubmit }: TrainingSessionProps) {
  const [scenario, setScenario] = useState('');
  const [decision, setDecision] = useState('');
  const [isActive, setIsActive] = useState(false);

  const handleSubmit = () => {
    if (scenario.trim() && decision.trim()) {
      onSubmit(scenario, decision);
      setScenario('');
      setDecision('');
      setIsActive(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <AIAvatar mood="learning" size={60} />
        <Text style={styles.title}>Train Your AI Twin</Text>
      </View>
      
      <TextInput
        style={styles.input}
        placeholder="Describe a situation you faced..."
        value={scenario}
        onChangeText={setScenario}
        multiline
        numberOfLines={3}
        onFocus={() => setIsActive(true)}
      />
      
      <TextInput
        style={styles.input}
        placeholder="What decision did you make?"
        value={decision}
        onChangeText={setDecision}
        multiline
        numberOfLines={2}
      />
      
      <TouchableOpacity 
        style={[styles.button, (!scenario.trim() || !decision.trim()) && styles.buttonDisabled]} 
        onPress={handleSubmit}
        disabled={!scenario.trim() || !decision.trim()}
      >
        <Text style={styles.buttonText}>Train AI Twin</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 16,
    color: '#333',
  },
  input: {
    borderWidth: 2,
    borderColor: '#e5e7eb',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    marginBottom: 16,
    backgroundColor: '#f9fafb',
    textAlignVertical: 'top',
  },
  button: {
    backgroundColor: '#6366f1',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  buttonDisabled: {
    backgroundColor: '#d1d5db',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});