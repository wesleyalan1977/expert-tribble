import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import BookCover from './BookCover';

interface PersonalizationPanelProps {
  onSave: (personalization: PersonalizationData) => void;
  initialData?: PersonalizationData;
}

export interface PersonalizationData {
  bookTitle: string;
  bookSubtitle: string;
  authorName: string;
  theme: 'strength' | 'power' | 'leadership' | 'warrior';
  personalQuote: string;
}

export default function PersonalizationPanel({ onSave, initialData }: PersonalizationPanelProps) {
  const [data, setData] = useState<PersonalizationData>({
    bookTitle: initialData?.bookTitle || 'THE WARRIOR\'S PATH',
    bookSubtitle: initialData?.bookSubtitle || 'MASTERING STRENGTH & DISCIPLINE',
    authorName: initialData?.authorName || 'MELCHIZEDEK',
    theme: initialData?.theme || 'strength',
    personalQuote: initialData?.personalQuote || 'I AM THE KING OF MY DOMAIN',
  });

  const themes = [
    { key: 'strength', label: 'STRENGTH', color: '#1a1a1a' },
    { key: 'power', label: 'POWER', color: '#0f172a' },
    { key: 'leadership', label: 'LEADERSHIP', color: '#18181b' },
    { key: 'warrior', label: 'WARRIOR', color: '#7f1d1d' },
  ] as const;

  const handleSave = () => {
    onSave(data);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>FORGE YOUR IDENTITY</Text>
      <Text style={styles.subtitle}>Build your personal brand of strength</Text>
      
      <View style={styles.previewSection}>
        <BookCover
          title={data.bookTitle}
          subtitle={data.bookSubtitle}
          authorName={data.authorName}
          theme={data.theme}
        />
      </View>
      
      <View style={styles.formSection}>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>TITLE</Text>
          <TextInput
            style={styles.input}
            value={data.bookTitle}
            onChangeText={(text) => setData(prev => ({ ...prev, bookTitle: text.toUpperCase() }))}
            placeholder="YOUR POWERFUL TITLE"
            placeholderTextColor="#666"
          />
        </View>
        
        <View style={styles.inputGroup}>
          <Text style={styles.label}>SUBTITLE</Text>
          <TextInput
            style={styles.input}
            value={data.bookSubtitle}
            onChangeText={(text) => setData(prev => ({ ...prev, bookSubtitle: text.toUpperCase() }))}
            placeholder="YOUR MISSION STATEMENT"
            placeholderTextColor="#666"
          />
        </View>
        
        <View style={styles.inputGroup}>
          <Text style={styles.label}>AUTHOR</Text>
          <TextInput
            style={styles.input}
            value={data.authorName}
            onChangeText={(text) => setData(prev => ({ ...prev, authorName: text.toUpperCase() }))}
            placeholder="YOUR NAME"
            placeholderTextColor="#666"
          />
        </View>
        
        <View style={styles.inputGroup}>
          <Text style={styles.label}>PERSONAL MANTRA</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            value={data.personalQuote}
            onChangeText={(text) => setData(prev => ({ ...prev, personalQuote: text.toUpperCase() }))}
            placeholder="YOUR DRIVING FORCE"
            placeholderTextColor="#666"
            multiline
          />
        </View>
        
        <View style={styles.inputGroup}>
          <Text style={styles.label}>THEME</Text>
          <View style={styles.themeGrid}>
            {themes.map((theme) => (
              <TouchableOpacity
                key={theme.key}
                style={[
                  styles.themeButton,
                  { backgroundColor: theme.color },
                  data.theme === theme.key && styles.selectedTheme
                ]}
                onPress={() => setData(prev => ({ ...prev, theme: theme.key }))}
              >
                <Text style={styles.themeText}>{theme.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
          <Text style={styles.saveButtonText}>FORGE IDENTITY</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    paddingTop: 60,
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 8,
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 16,
    color: '#cccccc',
    textAlign: 'center',
    marginBottom: 24,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  previewSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  formSection: {
    paddingHorizontal: 16,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 8,
    letterSpacing: 1.5,
  },
  input: {
    borderWidth: 2,
    borderColor: '#333',
    borderRadius: 4,
    padding: 16,
    fontSize: 16,
    backgroundColor: '#1a1a1a',
    color: '#ffffff',
    fontWeight: '600',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  themeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  themeButton: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 4,
    minWidth: 100,
    borderWidth: 2,
    borderColor: '#333',
  },
  selectedTheme: {
    borderColor: '#ff6b35',
    borderWidth: 3,
  },
  themeText: {
    color: 'white',
    fontWeight: '700',
    textAlign: 'center',
    letterSpacing: 1,
  },
  saveButton: {
    backgroundColor: '#ff6b35',
    paddingVertical: 18,
    borderRadius: 4,
    marginTop: 24,
    marginBottom: 32,
    borderWidth: 2,
    borderColor: '#ff8c5a',
  },
  saveButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '900',
    textAlign: 'center',
    letterSpacing: 2,
  },
});