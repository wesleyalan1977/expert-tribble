import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

interface AvatarCustomizerProps {
  onAvatarChange: (avatar: AvatarConfig) => void;
}

export interface AvatarConfig {
  face: string;
  body: string;
  accessory: string;
  background: string;
  personality: string;
}

const FACES = ['😊', '😎', '🤔', '💪', '🌟', '🔥', '💎', '🦋', '🌸', '⚡'];
const BODIES = ['👤', '🧘', '💃', '🏃', '🤸', '🧠', '💖', '🌈', '✨', '🎯'];
const ACCESSORIES = ['👑', '🎩', '🌺', '💍', '🎀', '🕶️', '⭐', '💫', '🔮', '🎪'];
const BACKGROUNDS = ['#8b5cf6', '#f59e0b', '#06b6d4', '#ef4444', '#10b981', '#f97316', '#ec4899', '#6366f1', '#84cc16', '#f43f5e'];
const PERSONALITIES = ['Confident', 'Wise', 'Energetic', 'Calm', 'Creative', 'Bold', 'Gentle', 'Fierce', 'Playful', 'Focused'];

export default function AvatarCustomizer({ onAvatarChange }: AvatarCustomizerProps) {
  const [avatar, setAvatar] = useState<AvatarConfig>({
    face: FACES[0],
    body: BODIES[0],
    accessory: ACCESSORIES[0],
    background: BACKGROUNDS[0],
    personality: PERSONALITIES[0]
  });

  const updateAvatar = (key: keyof AvatarConfig, value: string) => {
    const newAvatar = { ...avatar, [key]: value };
    setAvatar(newAvatar);
    onAvatarChange(newAvatar);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Customize Your AI Twin</Text>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Face Expression</Text>
        <View style={styles.optionsGrid}>
          {FACES.map((face) => (
            <TouchableOpacity
              key={face}
              style={[styles.option, avatar.face === face && styles.selected]}
              onPress={() => updateAvatar('face', face)}
            >
              <Text style={styles.optionText}>{face}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Body Style</Text>
        <View style={styles.optionsGrid}>
          {BODIES.map((body) => (
            <TouchableOpacity
              key={body}
              style={[styles.option, avatar.body === body && styles.selected]}
              onPress={() => updateAvatar('body', body)}
            >
              <Text style={styles.optionText}>{body}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Accessory</Text>
        <View style={styles.optionsGrid}>
          {ACCESSORIES.map((accessory) => (
            <TouchableOpacity
              key={accessory}
              style={[styles.option, avatar.accessory === accessory && styles.selected]}
              onPress={() => updateAvatar('accessory', accessory)}
            >
              <Text style={styles.optionText}>{accessory}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Background Color</Text>
        <View style={styles.optionsGrid}>
          {BACKGROUNDS.map((bg) => (
            <TouchableOpacity
              key={bg}
              style={[styles.colorOption, { backgroundColor: bg }, avatar.background === bg && styles.selectedColor]}
              onPress={() => updateAvatar('background', bg)}
            />
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Personality</Text>
        <View style={styles.optionsGrid}>
          {PERSONALITIES.map((personality) => (
            <TouchableOpacity
              key={personality}
              style={[styles.personalityOption, avatar.personality === personality && styles.selected]}
              onPress={() => updateAvatar('personality', personality)}
            >
              <Text style={[styles.personalityText, avatar.personality === personality && styles.selectedText]}>{personality}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f8fafc',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 30,
    textAlign: 'center',
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 15,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  option: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#e5e7eb',
  },
  selected: {
    borderColor: '#8b5cf6',
    backgroundColor: '#f3f4f6',
  },
  optionText: {
    fontSize: 24,
  },
  colorOption: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: '#e5e7eb',
  },
  selectedColor: {
    borderColor: '#1f2937',
    borderWidth: 3,
  },
  personalityOption: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e5e7eb',
    marginRight: 10,
    marginBottom: 10,
  },
  personalityText: {
    fontSize: 14,
    color: '#6b7280',
  },
  selectedText: {
    color: '#8b5cf6',
    fontWeight: '600',
  },
});