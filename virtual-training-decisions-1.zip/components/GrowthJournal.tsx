import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { supabase } from '../app/lib/supabase';

interface JournalEntry {
  id: string;
  week_number: number;
  question_1: string;
  question_2: string;
  question_3: string;
  created_at: string;
}

export default function GrowthJournal() {
  const [currentAnswers, setCurrentAnswers] = useState({
    question1: '',
    question2: '',
    question3: ''
  });
  const [pastEntries, setPastEntries] = useState<JournalEntry[]>([]);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [hasCurrentWeekEntry, setHasCurrentWeekEntry] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    calculateCurrentWeek();
  }, []);

  const calculateCurrentWeek = () => {
    const startDate = new Date('2025-01-01');
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - startDate.getTime());
    const diffWeeks = Math.ceil(diffTime / (1000 * 60 * 60 * 24 * 7));
    setCurrentWeek(diffWeeks);
  };

  const saveWeeklyEntry = async () => {
    if (!currentAnswers.question1 || !currentAnswers.question2 || !currentAnswers.question3) {
      Alert.alert('INCOMPLETE', 'Please answer all three questions before saving.');
      return;
    }

    setLoading(true);
    try {
      // Simulate saving to local storage instead of Supabase
      const newEntry: JournalEntry = {
        id: Date.now().toString(),
        week_number: currentWeek,
        question_1: currentAnswers.question1,
        question_2: currentAnswers.question2,
        question_3: currentAnswers.question3,
        created_at: new Date().toISOString()
      };
      
      setPastEntries(prev => [newEntry, ...prev]);
      Alert.alert('SAVED', 'Your weekly reflection has been recorded.');
      setHasCurrentWeekEntry(true);
    } catch (error) {
      console.error('Error saving journal entry:', error);
      Alert.alert('ERROR', 'Failed to save your entry. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerChange = (question: string, value: string) => {
    setCurrentAnswers(prev => ({ ...prev, [question]: value }));
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>GROWTH JOURNAL</Text>
      <Text style={styles.subtitle}>Week {currentWeek} • Track Your Evolution</Text>
      
      <View style={styles.currentWeekSection}>
        <Text style={styles.sectionTitle}>THIS WEEK'S REFLECTION</Text>
        
        <View style={styles.questionBlock}>
          <Text style={styles.questionNumber}>QUESTION #1</Text>
          <Text style={styles.questionText}>WHO DO YOU TALK ABOUT BEHIND THEIR BACK?</Text>
          <TextInput
            style={styles.answerInput}
            value={currentAnswers.question1}
            onChangeText={(text) => handleAnswerChange('question1', text)}
            placeholder="Be honest about your gossip habits..."
            placeholderTextColor="#666"
            multiline
            editable={!hasCurrentWeekEntry}
          />
        </View>

        <View style={styles.questionBlock}>
          <Text style={styles.questionNumber}>QUESTION #2</Text>
          <Text style={styles.questionText}>WHO HOLDS THE TOP POSITION IN YOUR HEART?</Text>
          <TextInput
            style={styles.answerInput}
            value={currentAnswers.question2}
            onChangeText={(text) => handleAnswerChange('question2', text)}
            placeholder="Who truly matters most to you?"
            placeholderTextColor="#666"
            multiline
            editable={!hasCurrentWeekEntry}
          />
        </View>

        <View style={styles.questionBlock}>
          <Text style={styles.questionNumber}>QUESTION #3</Text>
          <Text style={styles.questionText}>HOW DO YOU MEASURE A MAN'S GRIT?</Text>
          <TextInput
            style={styles.answerInput}
            value={currentAnswers.question3}
            onChangeText={(text) => handleAnswerChange('question3', text)}
            placeholder="What defines true resilience?"
            placeholderTextColor="#666"
            multiline
            editable={!hasCurrentWeekEntry}
          />
        </View>

        {!hasCurrentWeekEntry && (
          <TouchableOpacity 
            style={[styles.saveButton, loading && styles.saveButtonDisabled]} 
            onPress={saveWeeklyEntry}
            disabled={loading}
          >
            <Text style={styles.saveButtonText}>
              {loading ? 'SAVING...' : 'LOCK IN THIS WEEK'}
            </Text>
          </TouchableOpacity>
        )}
        
        {hasCurrentWeekEntry && (
          <View style={styles.lockedNotice}>
            <Text style={styles.lockedText}>✓ WEEK {currentWeek} LOCKED</Text>
            <Text style={styles.lockedSubtext}>Answers reset next week for continued growth</Text>
          </View>
        )}
      </View>

      {pastEntries.length > 0 && (
        <View style={styles.historySection}>
          <Text style={styles.sectionTitle}>GROWTH HISTORY</Text>
          {pastEntries.slice(0, 4).map((entry) => (
            <View key={entry.id} style={styles.historyEntry}>
              <Text style={styles.historyWeek}>WEEK {entry.week_number}</Text>
              <Text style={styles.historyDate}>
                {new Date(entry.created_at).toLocaleDateString()}
              </Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ff6b35',
    textAlign: 'center',
    marginBottom: 8,
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 14,
    color: '#ccc',
    textAlign: 'center',
    marginBottom: 32,
    letterSpacing: 1,
  },
  currentWeekSection: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ff6b35',
    marginBottom: 16,
    letterSpacing: 2,
  },
  questionBlock: {
    backgroundColor: '#1a1a1a',
    padding: 20,
    marginBottom: 24,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  questionNumber: {
    fontSize: 12,
    color: '#ff6b35',
    fontWeight: 'bold',
    marginBottom: 8,
    letterSpacing: 1,
  },
  questionText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 16,
    letterSpacing: 1,
  },
  answerInput: {
    backgroundColor: '#0a0a0a',
    color: '#fff',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333',
    fontSize: 16,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  saveButton: {
    backgroundColor: '#ff6b35',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  saveButtonDisabled: {
    backgroundColor: '#666',
  },
  saveButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  lockedNotice: {
    backgroundColor: '#1a1a1a',
    padding: 20,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
    borderWidth: 1,
    borderColor: '#4ade80',
  },
  lockedText: {
    fontSize: 16,
    color: '#4ade80',
    fontWeight: 'bold',
    letterSpacing: 2,
    marginBottom: 4,
  },
  lockedSubtext: {
    fontSize: 12,
    color: '#ccc',
    letterSpacing: 1,
  },
  historySection: {
    marginBottom: 40,
  },
  historyEntry: {
    backgroundColor: '#1a1a1a',
    padding: 16,
    marginBottom: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  historyWeek: {
    fontSize: 14,
    color: '#ff6b35',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  historyDate: {
    fontSize: 12,
    color: '#ccc',
  },
});