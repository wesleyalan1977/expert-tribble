import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

interface PathCardProps {
  title: string;
  description: string;
  icon: string;
  type: 'easy' | 'hard';
  selected: boolean;
  onPress: () => void;
}

export default function PathCard({ title, description, icon, type, selected, onPress }: PathCardProps) {
  const isEasy = type === 'easy';
  
  return (
    <TouchableOpacity
      style={[
        styles.card,
        isEasy ? styles.easyCard : styles.hardCard,
        selected && styles.selectedCard
      ]}
      onPress={onPress}
    >
      <View style={styles.header}>
        <Text style={styles.icon}>{icon}</Text>
        <View style={styles.pathType}>
          <Text style={[styles.typeText, isEasy ? styles.easyType : styles.hardType]}>
            {isEasy ? 'EASY PATH' : 'HARD PATH'}
          </Text>
        </View>
      </View>
      
      <Text style={[styles.title, isEasy ? styles.easyTitle : styles.hardTitle]}>
        {title}
      </Text>
      
      <Text style={[styles.description, isEasy ? styles.easyDesc : styles.hardDesc]}>
        {description}
      </Text>
      
      {selected && (
        <View style={[styles.selectedBadge, isEasy ? styles.easyBadge : styles.hardBadge]}>
          <Text style={styles.selectedText}>👑 CHOSEN PATH</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 2,
  },
  easyCard: {
    backgroundColor: '#f3f4f6',
    borderColor: '#9ca3af',
  },
  hardCard: {
    backgroundColor: '#1a1a1a',
    borderColor: '#f59e0b',
  },
  selectedCard: {
    borderWidth: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  icon: {
    fontSize: 32,
  },
  pathType: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  typeText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  easyType: {
    color: '#6b7280',
  },
  hardType: {
    color: '#f59e0b',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  easyTitle: {
    color: '#374151',
  },
  hardTitle: {
    color: '#f59e0b',
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
  },
  easyDesc: {
    color: '#6b7280',
  },
  hardDesc: {
    color: '#d1d5db',
  },
  selectedBadge: {
    marginTop: 16,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  easyBadge: {
    backgroundColor: '#dbeafe',
  },
  hardBadge: {
    backgroundColor: '#451a03',
  },
  selectedText: {
    fontWeight: 'bold',
    color: '#f59e0b',
  },
});