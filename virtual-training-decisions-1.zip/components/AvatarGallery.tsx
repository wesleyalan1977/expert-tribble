import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { AvatarConfig } from './AvatarCustomizer';
import AvatarPreview from './AvatarPreview';

interface AvatarGalleryProps {
  savedAvatars: AvatarConfig[];
  onSelectAvatar: (avatar: AvatarConfig) => void;
  onDeleteAvatar: (index: number) => void;
}

const PRESET_AVATARS: AvatarConfig[] = [
  {
    face: '💪',
    body: '🏃',
    accessory: '👑',
    background: '#ef4444',
    personality: 'Bold'
  },
  {
    face: '🌟',
    body: '🧘',
    accessory: '🌺',
    background: '#06b6d4',
    personality: 'Calm'
  },
  {
    face: '🔥',
    body: '💃',
    accessory: '💎',
    background: '#f59e0b',
    personality: 'Energetic'
  },
  {
    face: '🤔',
    body: '🧠',
    accessory: '🔮',
    background: '#8b5cf6',
    personality: 'Wise'
  },
  {
    face: '🦋',
    body: '🌈',
    accessory: '🎀',
    background: '#ec4899',
    personality: 'Creative'
  },
  {
    face: '⚡',
    body: '🎯',
    accessory: '⭐',
    background: '#10b981',
    personality: 'Focused'
  }
];

export default function AvatarGallery({ savedAvatars, onSelectAvatar, onDeleteAvatar }: AvatarGalleryProps) {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Avatar Gallery</Text>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preset Avatars</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.avatarRow}>
            {PRESET_AVATARS.map((avatar, index) => (
              <TouchableOpacity
                key={index}
                style={styles.avatarItem}
                onPress={() => onSelectAvatar(avatar)}
              >
                <AvatarPreview avatar={avatar} size={80} />
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>

      {savedAvatars.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Saved Avatars</Text>
          <View style={styles.savedAvatarsGrid}>
            {savedAvatars.map((avatar, index) => (
              <View key={index} style={styles.savedAvatarItem}>
                <TouchableOpacity
                  style={styles.avatarTouchable}
                  onPress={() => onSelectAvatar(avatar)}
                >
                  <AvatarPreview avatar={avatar} size={80} />
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.deleteButton}
                  onPress={() => onDeleteAvatar(index)}
                >
                  <Text style={styles.deleteText}>×</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginVertical: 20,
  },
  section: {
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 15,
  },
  avatarRow: {
    flexDirection: 'row',
    gap: 15,
    paddingRight: 20,
  },
  avatarItem: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  savedAvatarsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 15,
  },
  savedAvatarItem: {
    position: 'relative',
  },
  avatarTouchable: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  deleteButton: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#ef4444',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});