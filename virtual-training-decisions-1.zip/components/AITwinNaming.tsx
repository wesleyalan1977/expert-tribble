import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';

interface AITwinNamingProps {
  onNameSet: (name: string) => void;
  currentName?: string;
}

export default function AITwinNaming({ onNameSet, currentName }: AITwinNamingProps) {
  const [name, setName] = useState(currentName || 'Melchizedek');
  const [isEditing, setIsEditing] = useState(!currentName);

  const handleSave = () => {
    if (name.trim().length < 2) {
      Alert.alert('Invalid Name', 'Please enter at least 2 characters');
      return;
    }
    onNameSet(name.trim());
    setIsEditing(false);
  };

  if (!isEditing && currentName) {
    return (
      <View style={styles.nameDisplay}>
        <Text style={styles.nameText}>👑 {currentName}</Text>
        <TouchableOpacity onPress={() => setIsEditing(true)} style={styles.editButton}>
          <Text style={styles.editButtonText}>Edit</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Name Your AI Twin</Text>
      <TextInput
        style={styles.input}
        value={name}
        onChangeText={setName}
        placeholder="Enter a name for your AI twin"
        maxLength={20}
        autoFocus
      />
      <TouchableOpacity onPress={handleSave} style={styles.saveButton}>
        <Text style={styles.saveButtonText}>Save Name</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1a1a1a',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ff6b35',
  },
  nameDisplay: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ff6b35',
  },
  nameText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ff6b35',
  },
  editButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#333',
    borderRadius: 6,
  },
  editButtonText: {
    color: '#ff6b35',
    fontSize: 12,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ff6b35',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ff6b35',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 12,
    backgroundColor: '#000',
    color: '#fff',
  },
  saveButton: {
    backgroundColor: '#ff6b35',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#000',
    fontWeight: '600',
  },
});