import React, { useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import OptionDiscovery from './OptionDiscovery';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  hasOptions?: boolean;
  scenario?: string;
}

interface Option {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'hard';
  consequence: string;
}

export default function TrainingConversation() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "👑 I am Melchizedek, King of Salem. I see beyond the surface of your decisions. Share a situation where you feel stuck, and I will reveal options you never knew existed.",
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const scrollViewRef = useRef<ScrollView>(null);

  const scenarios = [
    "You're facing a difficult career decision",
    "Someone is pressuring you to compromise your values", 
    "You need to set boundaries with a toxic relationship",
    "You're considering a major life change",
    "You feel overwhelmed by others' expectations"
  ];

  const sendMessage = () => {
    if (!inputText.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isUser: true,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Generate AI response with options
    setTimeout(() => {
      const randomScenario = scenarios[Math.floor(Math.random() * scenarios.length)];
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: `⚔️ I sense the weight of your situation. People will judge your final decision, but they will never know the paths you considered. Let me show you the hidden options in this scenario:`,
        isUser: false,
        timestamp: new Date(),
        hasOptions: true,
        scenario: randomScenario
      };
      
      setMessages(prev => [...prev, aiResponse]);
    }, 1000);
  };

  const handleOptionSelect = (option: Option) => {
    const wisdom = option.difficulty === 'hard' 
      ? `🏆 You choose the path of kings - difficult but honorable. This builds character and self-respect.`
      : `⚠️ The easy path may seem appealing, but true strength comes from harder choices. Consider the long-term consequences.`;
    
    const wisdomMessage: Message = {
      id: (Date.now() + 2).toString(),
      text: wisdom,
      isUser: false,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, wisdomMessage]);
  };

  return (
    <View style={styles.container}>
      <ScrollView 
        ref={scrollViewRef}
        style={styles.messagesContainer}
        onContentSizeChange={() => scrollViewRef.current?.scrollToEnd()}
      >
        {messages.map((message) => (
          <View key={message.id}>
            <View style={[styles.message, message.isUser ? styles.userMessage : styles.aiMessage]}>
              <Text style={[styles.messageText, message.isUser ? styles.userText : styles.aiText]}>
                {message.text}
              </Text>
            </View>
            {message.hasOptions && message.scenario && (
              <OptionDiscovery 
                scenario={message.scenario}
                onOptionSelect={handleOptionSelect}
              />
            )}
          </View>
        ))}
      </ScrollView>
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          value={inputText}
          onChangeText={setInputText}
          placeholder="Share your situation with Melchizedek..."
          placeholderTextColor="#6b7280"
          multiline
        />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
          <Text style={styles.sendText}>⚔️</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f172a' },
  messagesContainer: { flex: 1, padding: 16 },
  message: { marginVertical: 8, padding: 16, borderRadius: 16, maxWidth: '85%' },
  userMessage: { alignSelf: 'flex-end', backgroundColor: '#1e40af', borderWidth: 1, borderColor: '#f97316' },
  aiMessage: { alignSelf: 'flex-start', backgroundColor: '#1f2937', borderWidth: 2, borderColor: '#f97316' },
  messageText: { fontSize: 16, lineHeight: 24 },
  userText: { color: '#e5e7eb' },
  aiText: { color: '#f97316', fontWeight: '600' },
  inputContainer: { flexDirection: 'row', padding: 16, backgroundColor: '#1f2937', borderTopWidth: 2, borderTopColor: '#f97316', alignItems: 'flex-end' },
  textInput: { flex: 1, borderWidth: 2, borderColor: '#f97316', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginRight: 12, maxHeight: 100, fontSize: 16, color: '#e5e7eb', backgroundColor: '#0f172a' },
  sendButton: { backgroundColor: '#f97316', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12 },
  sendText: { color: '#0f172a', fontSize: 18, fontWeight: '700' }
});