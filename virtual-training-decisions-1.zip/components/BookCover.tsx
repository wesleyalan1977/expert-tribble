import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface BookCoverProps {
  title: string;
  subtitle?: string;
  authorName: string;
  theme: 'strength' | 'power' | 'leadership' | 'warrior';
}

export default function BookCover({ title, subtitle, authorName, theme }: BookCoverProps) {
  const getThemeColors = () => {
    switch (theme) {
      case 'strength':
        return { primary: '#1a1a1a', secondary: '#2d2d2d', accent: '#ff6b35', text: '#ffffff' };
      case 'power':
        return { primary: '#0f172a', secondary: '#1e293b', accent: '#3b82f6', text: '#ffffff' };
      case 'leadership':
        return { primary: '#18181b', secondary: '#27272a', accent: '#eab308', text: '#ffffff' };
      case 'warrior':
        return { primary: '#7f1d1d', secondary: '#991b1b', accent: '#fbbf24', text: '#ffffff' };
      default:
        return { primary: '#1a1a1a', secondary: '#2d2d2d', accent: '#ff6b35', text: '#ffffff' };
    }
  };

  const colors = getThemeColors();

  return (
    <View style={[styles.bookCover, { backgroundColor: colors.primary }]}>
      <View style={styles.metalFrame}>
        <View style={[styles.frameTop, { backgroundColor: colors.accent }]} />
        <View style={[styles.frameBottom, { backgroundColor: colors.accent }]} />
      </View>
      
      <View style={styles.coverContent}>
        <View style={styles.titleSection}>
          <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
          {subtitle && (
            <View style={[styles.subtitleBar, { backgroundColor: colors.accent }]}>
              <Text style={[styles.subtitle, { color: colors.primary }]}>{subtitle}</Text>
            </View>
          )}
        </View>
        
        <View style={styles.centerElement}>
          <View style={[styles.diamond, { borderColor: colors.accent }]}>
            <View style={[styles.innerDiamond, { backgroundColor: colors.accent }]} />
          </View>
          <View style={[styles.horizontalBars, { backgroundColor: colors.secondary }]} />
        </View>
        
        <View style={styles.authorSection}>
          <View style={[styles.authorBar, { backgroundColor: colors.secondary }]}>
            <Text style={[styles.author, { color: colors.text }]}>{authorName}</Text>
          </View>
        </View>
      </View>
      
      <View style={[styles.spine, { backgroundColor: colors.secondary }]}>
        <View style={[styles.spineAccent, { backgroundColor: colors.accent }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bookCover: {
    width: 200,
    height: 280,
    borderRadius: 4,
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 8 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 12,
    position: 'relative',
    borderWidth: 2,
    borderColor: '#333',
  },
  metalFrame: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1,
  },
  frameTop: {
    position: 'absolute',
    top: 8,
    left: 8,
    right: 8,
    height: 4,
  },
  frameBottom: {
    position: 'absolute',
    bottom: 8,
    left: 8,
    right: 8,
    height: 4,
  },
  coverContent: {
    flex: 1,
    padding: 20,
    justifyContent: 'space-between',
    zIndex: 2,
  },
  titleSection: {
    alignItems: 'center',
    marginTop: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: '900',
    textAlign: 'center',
    lineHeight: 22,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  subtitleBar: {
    marginTop: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 2,
  },
  subtitle: {
    fontSize: 10,
    textAlign: 'center',
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  centerElement: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  diamond: {
    width: 40,
    height: 40,
    borderWidth: 3,
    transform: [{ rotate: '45deg' }],
    justifyContent: 'center',
    alignItems: 'center',
  },
  innerDiamond: {
    width: 16,
    height: 16,
    transform: [{ rotate: '-45deg' }],
  },
  horizontalBars: {
    width: 100,
    height: 3,
    marginTop: 15,
  },
  authorSection: {
    alignItems: 'center',
    marginBottom: 10,
  },
  authorBar: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 2,
    borderWidth: 1,
    borderColor: '#444',
  },
  author: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 2,
    textTransform: 'uppercase',
  },
  spine: {
    position: 'absolute',
    right: -3,
    top: 0,
    bottom: 0,
    width: 12,
    borderTopRightRadius: 4,
    borderBottomRightRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
  },
  spineAccent: {
    width: 6,
    height: 60,
    borderRadius: 3,
  },
});