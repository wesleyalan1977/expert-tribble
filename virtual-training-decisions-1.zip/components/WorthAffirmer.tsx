import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated } from 'react-native';

const WORTH_STATEMENTS = [
  "I am inherently valuable, regardless of what others think",
  "My worth is not determined by my productivity or achievements",
  "I deserve love, respect, and kindness from others",
  "I have unique gifts and perspectives to offer the world",
  "My feelings and needs are valid and important",
  "I am worthy of healthy, supportive relationships",
  "I deserve to take up space and be heard",
  "My boundaries are a reflection of my self-worth",
  "I am complete and whole as I am right now",
  "I choose to treat myself with compassion and respect"
];

export default function WorthAffirmer() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fadeAnim] = useState(new Animated.Value(1));
  const [dailyCount, setDailyCount] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAutoPlay) {
      interval = setInterval(() => {
        nextStatement();
      }, 4000);
    }
    return () => clearInterval(interval);
  }, [isAutoPlay, currentIndex]);

  const nextStatement = () => {
    Animated.sequence([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      })
    ]).start();
    
    setCurrentIndex((prev) => (prev + 1) % WORTH_STATEMENTS.length);
  };

  const previousStatement = () => {
    Animated.sequence([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      })
    ]).start();
    
    setCurrentIndex((prev) => prev === 0 ? WORTH_STATEMENTS.length - 1 : prev - 1);
  };

  const affirmWorth = () => {
    setDailyCount(prev => prev + 1);
    // Add haptic feedback or animation here
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Know Your Worth</Text>
      <Text style={styles.subtitle}>
        Daily reminders of your inherent value
      </Text>
      
      <View style={styles.counterContainer}>
        <Text style={styles.counterText}>
          Today's affirmations: {dailyCount}
        </Text>
      </View>

      <View style={styles.statementContainer}>
        <Animated.View style={[styles.statementCard, { opacity: fadeAnim }]}>
          <Text style={styles.statementText}>
            {WORTH_STATEMENTS[currentIndex]}
          </Text>
        </Animated.View>
      </View>

      <View style={styles.controls}>
        <TouchableOpacity style={styles.navButton} onPress={previousStatement}>
          <Text style={styles.navButtonText}>←</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.affirmButton} 
          onPress={affirmWorth}
        >
          <Text style={styles.affirmButtonText}>I Affirm This ✨</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.navButton} onPress={nextStatement}>
          <Text style={styles.navButtonText}>→</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity 
        style={[
          styles.autoPlayButton,
          isAutoPlay && styles.autoPlayActive
        ]}
        onPress={() => setIsAutoPlay(!isAutoPlay)}
      >
        <Text style={[
          styles.autoPlayText,
          isAutoPlay && styles.autoPlayActiveText
        ]}>
          {isAutoPlay ? 'Stop Auto-Play' : 'Start Auto-Play'}
        </Text>
      </TouchableOpacity>

      <View style={styles.progress}>
        <View style={styles.progressBar}>
          <View 
            style={[
              styles.progressFill,
              { width: `${((currentIndex + 1) / WORTH_STATEMENTS.length) * 100}%` }
            ]}
          />
        </View>
        <Text style={styles.progressText}>
          {currentIndex + 1} of {WORTH_STATEMENTS.length}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 20,
  },
  counterContainer: {
    backgroundColor: '#fef3c7',
    padding: 12,
    borderRadius: 8,
    marginBottom: 24,
  },
  counterText: {
    textAlign: 'center',
    color: '#92400e',
    fontWeight: '600',
  },
  statementContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 20,
  },
  statementCard: {
    backgroundColor: '#f8fafc',
    padding: 24,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statementText: {
    fontSize: 18,
    lineHeight: 28,
    color: '#1f2937',
    textAlign: 'center',
    fontWeight: '500',
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  navButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#f3f4f6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  navButtonText: {
    fontSize: 20,
    color: '#6b7280',
  },
  affirmButton: {
    backgroundColor: '#8b5cf6',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
    flex: 1,
    marginHorizontal: 12,
  },
  affirmButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  autoPlayButton: {
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignSelf: 'center',
    marginBottom: 20,
  },
  autoPlayActive: {
    backgroundColor: '#3b82f6',
  },
  autoPlayText: {
    color: '#6b7280',
    fontSize: 14,
  },
  autoPlayActiveText: {
    color: '#fff',
  },
  progress: {
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#e5e7eb',
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#8b5cf6',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 12,
    color: '#6b7280',
  },
});