import React, { useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert } from 'react-native';
import { supabase } from '@/app/lib/supabase';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

interface ConversationProps {
  onPersonalityDetected: (traits: string[]) => void;
  onGoalsGenerated: (goals: string[]) => void;
}

export default function ConversationInterface({ onPersonalityDetected, onGoalsGenerated }: ConversationProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your AI twin. Let's talk about who you are and who you'd like to become. What's on your mind?",
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  const sendMessage = async () => {
    if (!inputText.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isUser: true,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputText;
    setInputText('');

    try {
      const response = await fetch(
        'https://vdnvpolivbxtdtyaldan.supabase.co/functions/v1/6523d4d4-e850-439c-bd44-6b9c1c19154b',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: currentInput,
            conversationHistory: messages,
            detectedTraits: []
          })
        }
      );

      const data = await response.json();
      
      if (data.detectedTraits && data.detectedTraits.length > 0) {
        onPersonalityDetected(data.detectedTraits);
      }
      
      if (data.suggestions && data.suggestions.goals && data.suggestions.goals.length > 0) {
        onGoalsGenerated(data.suggestions.goals);
      }

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: data.response || "I understand. Tell me more about that.",
        isUser: false,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      const errorResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm having trouble processing that. Can you tell me more about your feelings?",
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorResponse]);
    }
  };

  const startListening = () => {
    setIsListening(true);
    setTimeout(() => {
      setIsListening(false);
      Alert.alert('Voice Note', 'Voice feature simulated - would process audio here');
    }, 2000);
  };

  return (
    <View style={styles.container}>
      <ScrollView 
        ref={scrollViewRef}
        style={styles.messagesContainer}
        onContentSizeChange={() => scrollViewRef.current?.scrollToEnd()}
      >
        {messages.map((message) => (
          <View key={message.id} style={[styles.message, message.isUser ? styles.userMessage : styles.aiMessage]}>
            <Text style={[styles.messageText, message.isUser ? styles.userText : styles.aiText]}>
              {message.text}
            </Text>
          </View>
        ))}
      </ScrollView>
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          value={inputText}
          onChangeText={setInputText}
          placeholder="Share your thoughts..."
          multiline
          maxLength={500}
        />
        <TouchableOpacity 
          style={[styles.button, styles.voiceButton, isListening && styles.listeningButton]} 
          onPress={startListening}
        >
          <Text style={styles.buttonText}>{isListening ? '🎤' : '🎙️'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={sendMessage}>
          <Text style={styles.buttonText}>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  messagesContainer: { flex: 1, padding: 16 },
  message: { marginVertical: 8, padding: 12, borderRadius: 16, maxWidth: '80%' },
  userMessage: { alignSelf: 'flex-end', backgroundColor: '#6366f1' },
  aiMessage: { alignSelf: 'flex-start', backgroundColor: 'white', borderWidth: 1, borderColor: '#e2e8f0' },
  messageText: { fontSize: 16, lineHeight: 22 },
  userText: { color: 'white' },
  aiText: { color: '#374151' },
  inputContainer: { flexDirection: 'row', padding: 16, backgroundColor: 'white', borderTopWidth: 1, borderTopColor: '#e2e8f0', alignItems: 'flex-end' },
  textInput: { flex: 1, borderWidth: 1, borderColor: '#d1d5db', borderRadius: 20, paddingHorizontal: 16, paddingVertical: 12, marginRight: 8, maxHeight: 100, fontSize: 16 },
  button: { backgroundColor: '#6366f1', paddingHorizontal: 16, paddingVertical: 12, borderRadius: 20, marginLeft: 4 },
  voiceButton: { backgroundColor: '#10b981' },
  listeningButton: { backgroundColor: '#ef4444' },
  buttonText: { color: 'white', fontWeight: '600' }
});