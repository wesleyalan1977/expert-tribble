import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

interface Option {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'hard';
  consequence: string;
}

interface OptionDiscoveryProps {
  scenario: string;
  onOptionSelect: (option: Option) => void;
}

export default function OptionDiscovery({ scenario, onOptionSelect }: OptionDiscoveryProps) {
  const [revealedOptions, setRevealedOptions] = useState<string[]>([]);
  
  const options: Option[] = [
    {
      id: '1',
      title: '👥 Seek Others\'ᅟ Approval',
      description: 'Ask friends what they think you should do',
      difficulty: 'easy',
      consequence: 'Quick validation but dependency on others'
    },
    {
      id: '2', 
      title: '🤔 Deep Self-Reflection',
      description: 'Spend time analyzing your true values and desires',
      difficulty: 'hard',
      consequence: 'Challenging but builds authentic self-knowledge'
    },
    {
      id: '3',
      title: '📊 Research & Analysis', 
      description: 'Gather data and expert opinions independently',
      difficulty: 'hard',
      consequence: 'Time-consuming but leads to informed decisions'
    },
    {
      id: '4',
      title: '⚡ Go with Gut Feeling',
      description: 'Make a quick decision based on first instinct',
      difficulty: 'easy',
      consequence: 'Fast but may miss important considerations'
    }
  ];

  const revealOption = (optionId: string) => {
    if (!revealedOptions.includes(optionId)) {
      setRevealedOptions([...revealedOptions, optionId]);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.scenario}>{scenario}</Text>
      <Text style={styles.subtitle}>👑 Melchizedek reveals your hidden options:</Text>
      
      {options.map((option) => (
        <View key={option.id} style={styles.optionContainer}>
          {!revealedOptions.includes(option.id) ? (
            <TouchableOpacity 
              style={styles.hiddenOption} 
              onPress={() => revealOption(option.id)}
            >
              <Text style={styles.hiddenText}>🔒 Tap to reveal option</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity 
              style={[
                styles.revealedOption,
                option.difficulty === 'hard' ? styles.hardOption : styles.easyOption
              ]}
              onPress={() => onOptionSelect(option)}
            >
              <Text style={styles.optionTitle}>{option.title}</Text>
              <Text style={styles.optionDescription}>{option.description}</Text>
              <Text style={styles.consequence}>⚖️ {option.consequence}</Text>
            </TouchableOpacity>
          )}
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16 },
  scenario: { fontSize: 16, color: '#f97316', marginBottom: 16, fontWeight: '600' },
  subtitle: { fontSize: 14, color: '#d97706', marginBottom: 12, fontStyle: 'italic' },
  optionContainer: { marginBottom: 12 },
  hiddenOption: { backgroundColor: '#1f2937', padding: 16, borderRadius: 12, borderWidth: 2, borderColor: '#374151' },
  hiddenText: { color: '#9ca3af', textAlign: 'center', fontSize: 14 },
  revealedOption: { padding: 16, borderRadius: 12, borderWidth: 2 },
  hardOption: { backgroundColor: '#0f172a', borderColor: '#f97316' },
  easyOption: { backgroundColor: '#1f2937', borderColor: '#6b7280' },
  optionTitle: { color: '#f97316', fontSize: 16, fontWeight: '700', marginBottom: 8 },
  optionDescription: { color: '#e5e7eb', fontSize: 14, marginBottom: 8 },
  consequence: { color: '#d97706', fontSize: 12, fontStyle: 'italic' }
});