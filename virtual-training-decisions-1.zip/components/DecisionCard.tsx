import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { supabase } from '../app/lib/supabase';
import { useRouter } from 'expo-router';

interface DecisionCardProps {
  title: string;
  userChoice: string;
  aiSuggestion: string;
  confidence: number;
  onSelect: (choice: 'user' | 'ai') => void;
}

export default function DecisionCard({ 
  title, 
  userChoice, 
  aiSuggestion, 
  confidence, 
  onSelect 
}: DecisionCardProps) {
  const router = useRouter();
  
  const detectEasyPath = (choice: string, suggestion: string) => {
    const easyKeywords = [
      'give up', 'quit', 'easy way', 'shortcut', 'avoid', 'skip',
      'ignore', 'later', 'tomorrow', 'not now', 'too hard',
      'can\'t do', 'impossible', 'not worth', 'lazy', 'procrastinate'
    ];
    
    const hardKeywords = [
      'work hard', 'push through', 'challenge', 'overcome', 'persist',
      'dedication', 'commitment', 'effort', 'discipline', 'growth',
      'improve', 'learn', 'practice', 'struggle', 'fight'
    ];
    
    const choiceLower = choice.toLowerCase();
    const suggestionLower = suggestion.toLowerCase();
    
    const userChoseEasy = easyKeywords.some(keyword => 
      choiceLower.includes(keyword)
    );
    
    const aiSuggestedHard = hardKeywords.some(keyword => 
      suggestionLower.includes(keyword)
    );
    
    return userChoseEasy && aiSuggestedHard;
  };
  
  const handleEasyPath = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      await supabase
        .from('user_activity')
        .update({ 
          continuous_days: 0,
          last_activity_date: new Date().toISOString()
        })
        .eq('user_id', user.id);
      
      Alert.alert(
        'Easy Path Detected',
        'You chose the easy path. Your 180-day tracker has been reset. You will be logged out.',
        [{ 
          text: 'OK', 
          onPress: async () => {
            await supabase.auth.signOut();
            router.replace('/');
          }
        }]
      );
    } catch (error) {
      console.error('Error handling easy path:', error);
    }
  };
  
  const handleSelection = (choice: 'user' | 'ai') => {
    if (choice === 'user' && detectEasyPath(userChoice, aiSuggestion)) {
      handleEasyPath();
      return;
    }
    onSelect(choice);
  };
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      
      <TouchableOpacity 
        style={[styles.option, styles.userOption]} 
        onPress={() => handleSelection('user')}
      >
        <Text style={styles.optionLabel}>YOUR CHOICE</Text>
        <Text style={styles.optionText}>{userChoice}</Text>
      </TouchableOpacity>
      
      <TouchableOpacity 
        style={[styles.option, styles.aiOption]} 
        onPress={() => handleSelection('ai')}
      >
        <Text style={styles.optionLabel}>AI SUGGESTION</Text>
        <Text style={styles.optionText}>{aiSuggestion}</Text>
        <View style={styles.confidenceBar}>
          <View 
            style={[styles.confidenceFill, { width: `${confidence}%` }]} 
          />
        </View>
        <Text style={styles.confidenceText}>{confidence}% CONFIDENCE</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 20,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#fff',
    letterSpacing: 1,
  },
  option: {
    padding: 16,
    borderRadius: 12,
    marginVertical: 6,
    borderWidth: 2,
  },
  userOption: {
    backgroundColor: '#0a0a0a',
    borderColor: '#ff6b35',
  },
  aiOption: {
    backgroundColor: '#0a0a0a',
    borderColor: '#666',
  },
  optionLabel: {
    fontSize: 12,
    fontWeight: '800',
    color: '#ff6b35',
    marginBottom: 8,
    letterSpacing: 1.5,
  },
  optionText: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 8,
    lineHeight: 22,
  },
  confidenceBar: {
    height: 4,
    backgroundColor: '#333',
    borderRadius: 2,
    marginBottom: 4,
  },
  confidenceFill: {
    height: '100%',
    backgroundColor: '#ff6b35',
    borderRadius: 2,
  },
  confidenceText: {
    fontSize: 12,
    color: '#999',
    fontWeight: '600',
    letterSpacing: 0.5,
  },
});