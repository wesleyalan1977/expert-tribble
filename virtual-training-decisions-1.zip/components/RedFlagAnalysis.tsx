import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

interface RedFlag {
  id: string;
  analysis: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high';
}

interface RedFlagAnalysisProps {
  redFlags: RedFlag[];
  onClearFlags: () => void;
}

export default function RedFlagAnalysis({ redFlags, onClearFlags }: RedFlagAnalysisProps) {
  if (redFlags.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>🛡️ No red flags detected</Text>
        <Text style={styles.emptySubtext}>Your AI twin is monitoring for concerning behaviors</Text>
      </View>
    );
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return '#ef4444';
      case 'medium': return '#f59e0b';
      case 'low': return '#10b981';
      default: return '#6b7280';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high': return '🚨';
      case 'medium': return '⚠️';
      case 'low': return '💡';
      default: return '📝';
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>🚩 Behavior Analysis</Text>
        <TouchableOpacity onPress={onClearFlags} style={styles.clearButton}>
          <Text style={styles.clearButtonText}>Clear</Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView style={styles.flagsList} showsVerticalScrollIndicator={false}>
        {redFlags.map((flag) => (
          <View key={flag.id} style={styles.flagItem}>
            <View style={styles.flagHeader}>
              <Text style={styles.flagIcon}>{getSeverityIcon(flag.severity)}</Text>
              <Text style={[styles.flagSeverity, { color: getSeverityColor(flag.severity) }]}>
                {flag.severity.toUpperCase()}
              </Text>
              <Text style={styles.flagTime}>
                {flag.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </View>
            <Text style={styles.flagText}>{flag.analysis}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    maxHeight: 300,
  },
  emptyContainer: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10b981',
    marginBottom: 4,
  },
  emptySubtext: {
    fontSize: 12,
    color: '#6b7280',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1f2937',
  },
  clearButton: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: '#f3f4f6',
    borderRadius: 4,
  },
  clearButtonText: {
    fontSize: 12,
    color: '#6b7280',
  },
  flagsList: {
    maxHeight: 200,
  },
  flagItem: {
    backgroundColor: '#f9fafb',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#ef4444',
  },
  flagHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  flagIcon: {
    marginRight: 8,
  },
  flagSeverity: {
    fontSize: 10,
    fontWeight: 'bold',
    marginRight: 8,
  },
  flagTime: {
    fontSize: 10,
    color: '#9ca3af',
    marginLeft: 'auto',
  },
  flagText: {
    fontSize: 14,
    color: '#374151',
    lineHeight: 18,
  },
});