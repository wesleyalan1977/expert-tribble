import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface AIAvatarProps {
  mood: 'thinking' | 'confident' | 'learning';
  size?: number;
  name?: string;
}

export default function AIAvatar({ mood, size = 80, name = 'Melchizedek' }: AIAvatarProps) {
  const getBackgroundColor = () => {
    switch (mood) {
      case 'thinking': return '#1a1a1a';
      case 'confident': return '#ff6b35';
      case 'learning': return '#333';
      default: return '#1a1a1a';
    }
  };

  const getEmoji = () => {
    switch (mood) {
      case 'thinking': return '👑';
      case 'confident': return '⚔️';
      case 'learning': return '📜';
      default: return '👑';
    }
  };

  const getMoodText = () => {
    switch (mood) {
      case 'thinking': return 'CONTEMPLATING';
      case 'confident': return 'COMMANDING';
      case 'learning': return 'ABSORBING WISDOM';
      default: return 'READY';
    }
  };

  return (
    <View style={[styles.container, { width: size + 20, height: size + 40 }]}>
      <View
        style={[
          styles.avatar, 
          { 
            width: size, 
            height: size, 
            borderRadius: size / 2,
            backgroundColor: getBackgroundColor()
          }
        ]}
      >
        <Text style={[styles.emoji, { fontSize: size * 0.4 }]}>
          {getEmoji()}
        </Text>
      </View>
      <Text style={styles.nameText}>{name}</Text>
      <Text style={styles.moodText}>{getMoodText()}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    shadowColor: '#ff6b35',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  avatar: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#ff6b35',
  },
  emoji: {
    color: 'white',
  },
  nameText: {
    color: '#ff6b35',
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: 4,
    textAlign: 'center',
  },
  moodText: {
    color: '#999',
    fontSize: 10,
    fontWeight: '600',
    marginTop: 2,
    textAlign: 'center',
  },
});