import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput } from 'react-native';

interface Boundary {
  id: string;
  title: string;
  description: string;
  isSet: boolean;
  category: 'personal' | 'work' | 'relationships';
}

const DEFAULT_BOUNDARIES: Boundary[] = [
  {
    id: '1',
    title: 'No interrupting during conversations',
    description: 'I will not allow others to consistently interrupt me',
    isSet: false,
    category: 'personal'
  },
  {
    id: '2', 
    title: 'Respect my time commitments',
    description: 'I expect others to honor scheduled time together',
    isSet: false,
    category: 'relationships'
  },
  {
    id: '3',
    title: 'No work calls after hours',
    description: 'I maintain separation between work and personal time',
    isSet: false,
    category: 'work'
  },
  {
    id: '4',
    title: 'Honest communication required',
    description: 'I will not tolerate dishonesty or manipulation',
    isSet: false,
    category: 'relationships'
  }
];

export default function BoundaryTracker() {
  const [boundaries, setBoundaries] = useState<Boundary[]>(DEFAULT_BOUNDARIES);
  const [newBoundary, setNewBoundary] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const toggleBoundary = (id: string) => {
    setBoundaries(prev => prev.map(boundary => 
      boundary.id === id ? { ...boundary, isSet: !boundary.isSet } : boundary
    ));
  };

  const addCustomBoundary = () => {
    if (newBoundary.trim()) {
      const boundary: Boundary = {
        id: Date.now().toString(),
        title: newBoundary.trim(),
        description: 'Custom boundary',
        isSet: false,
        category: 'personal'
      };
      setBoundaries(prev => [...prev, boundary]);
      setNewBoundary('');
    }
  };

  const filteredBoundaries = selectedCategory === 'all' 
    ? boundaries 
    : boundaries.filter(b => b.category === selectedCategory);

  const setBoundariesCount = boundaries.filter(b => b.isSet).length;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Boundary Tracker</Text>
      <Text style={styles.subtitle}>
        Healthy boundaries create healthy relationships
      </Text>
      
      <View style={styles.stats}>
        <Text style={styles.statsText}>
          {setBoundariesCount} of {boundaries.length} boundaries set
        </Text>
      </View>

      <View style={styles.categoryButtons}>
        {['all', 'personal', 'work', 'relationships'].map(category => (
          <TouchableOpacity
            key={category}
            style={[
              styles.categoryButton,
              selectedCategory === category && styles.activeCategoryButton
            ]}
            onPress={() => setSelectedCategory(category)}
          >
            <Text style={[
              styles.categoryButtonText,
              selectedCategory === category && styles.activeCategoryButtonText
            ]}>
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.boundariesList}>
        {filteredBoundaries.map(boundary => (
          <TouchableOpacity
            key={boundary.id}
            style={[
              styles.boundaryCard,
              boundary.isSet && styles.setBoundaryCard
            ]}
            onPress={() => toggleBoundary(boundary.id)}
          >
            <View style={styles.boundaryContent}>
              <Text style={[
                styles.boundaryTitle,
                boundary.isSet && styles.setBoundaryTitle
              ]}>
                {boundary.title}
              </Text>
              <Text style={styles.boundaryDescription}>
                {boundary.description}
              </Text>
            </View>
            <View style={[
              styles.checkbox,
              boundary.isSet && styles.checkedBox
            ]}>
              {boundary.isSet && <Text style={styles.checkmark}>✓</Text>}
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.addBoundary}>
        <TextInput
          style={styles.input}
          placeholder="Add a custom boundary..."
          value={newBoundary}
          onChangeText={setNewBoundary}
          onSubmitEditing={addCustomBoundary}
        />
        <TouchableOpacity style={styles.addButton} onPress={addCustomBoundary}>
          <Text style={styles.addButtonText}>Add</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 16,
  },
  stats: {
    backgroundColor: '#f0f9ff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  statsText: {
    textAlign: 'center',
    color: '#0369a1',
    fontWeight: '600',
  },
  categoryButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  categoryButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: '#f3f4f6',
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  activeCategoryButton: {
    backgroundColor: '#3b82f6',
    borderColor: '#3b82f6',
  },
  categoryButtonText: {
    fontSize: 12,
    color: '#6b7280',
  },
  activeCategoryButtonText: {
    color: '#fff',
  },
  boundariesList: {
    flex: 1,
  },
  boundaryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#f9fafb',
    borderWidth: 1,
    borderColor: '#e5e7eb',
    marginBottom: 12,
  },
  setBoundaryCard: {
    backgroundColor: '#f0f9ff',
    borderColor: '#3b82f6',
  },
  boundaryContent: {
    flex: 1,
  },
  boundaryTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  setBoundaryTitle: {
    color: '#1e40af',
  },
  boundaryDescription: {
    fontSize: 14,
    color: '#6b7280',
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: '#d1d5db',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  checkedBox: {
    backgroundColor: '#3b82f6',
    borderColor: '#3b82f6',
  },
  checkmark: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  addBoundary: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 16,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 16,
  },
  addButton: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    justifyContent: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
});