import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface AITwinPersonalityFormProps {
  onSubmit: (data: { issues: string[]; strengths: string[] }) => void;
  initialData?: { issues: string[]; strengths: string[] };
  isAIMode?: boolean;
}

const GENTLE_ISSUES = [
  'Sometimes feels overwhelmed by decisions',
  'Occasionally procrastinates on important tasks',
  'Can be too hard on themselves',
  'Struggles with saying no to others',
  'Tends to overthink situations',
  'Sometimes avoids difficult conversations',
  'Can be impatient with slow progress',
  'Occasionally doubts their abilities'
];

const SUPPORTIVE_STRENGTHS = [
  'Shows genuine care for others',
  'Has strong problem-solving skills',
  'Demonstrates resilience in challenges',
  'Possesses natural leadership qualities',
  'Excellent at listening to others',
  'Creative in finding solutions',
  'Maintains optimism in difficult times',
  'Strong sense of responsibility'
];

export default function AITwinPersonalityForm({ onSubmit, initialData, isAIMode = false }: AITwinPersonalityFormProps) {
  const [issues, setIssues] = useState<string[]>(initialData?.issues || []);
  const [strengths, setStrengths] = useState<string[]>(initialData?.strengths || []);
  const [currentIssue, setCurrentIssue] = useState('');
  const [currentStrength, setCurrentStrength] = useState('');
  const [aiSuggestionIndex, setAiSuggestionIndex] = useState(0);

  useEffect(() => {
    if (isAIMode && issues.length < 3) {
      const timer = setTimeout(() => {
        suggestNextTrait();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [issues, strengths, isAIMode, aiSuggestionIndex]);

  const suggestNextTrait = () => {
    if (Math.random() > 0.5 && issues.length < 4) {
      const availableIssues = GENTLE_ISSUES.filter(issue => !issues.includes(issue));
      if (availableIssues.length > 0) {
        const suggestion = availableIssues[aiSuggestionIndex % availableIssues.length];
        Alert.alert(
          'AI Twin Insight',
          `I've noticed you might: "${suggestion}". Does this resonate with you?`,
          [
            { text: 'Not really', style: 'cancel' },
            { text: 'Yes, add it', onPress: () => addIssue(suggestion) }
          ]
        );
      }
    } else if (strengths.length < 4) {
      const availableStrengths = SUPPORTIVE_STRENGTHS.filter(strength => !strengths.includes(strength));
      if (availableStrengths.length > 0) {
        const suggestion = availableStrengths[aiSuggestionIndex % availableStrengths.length];
        Alert.alert(
          'AI Twin Recognition',
          `I see that you: "${suggestion}". Would you like to acknowledge this strength?`,
          [
            { text: 'Maybe later', style: 'cancel' },
            { text: 'Yes, add it', onPress: () => addStrength(suggestion) }
          ]
        );
      }
    }
    setAiSuggestionIndex(prev => prev + 1);
  };

  const addIssue = (issue?: string) => {
    const newIssue = issue || currentIssue.trim();
    if (newIssue && !issues.includes(newIssue)) {
      setIssues([...issues, newIssue]);
      setCurrentIssue('');
    }
  };

  const addStrength = (strength?: string) => {
    const newStrength = strength || currentStrength.trim();
    if (newStrength && !strengths.includes(newStrength)) {
      setStrengths([...strengths, newStrength]);
      setCurrentStrength('');
    }
  };

  const removeIssue = (index: number) => {
    setIssues(issues.filter((_, i) => i !== index));
  };

  const removeStrength = (index: number) => {
    setStrengths(strengths.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    onSubmit({ issues, strengths });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>
        {isAIMode ? 'AI Twin Observations' : 'Areas for Growth'}
      </Text>
      <Text style={styles.sectionDescription}>
        {isAIMode 
          ? 'Your AI twin gently identifies patterns that might be holding you back'
          : 'What challenges would you like to work on?'}
      </Text>
      
      {!isAIMode && (
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            value={currentIssue}
            onChangeText={setCurrentIssue}
            placeholder="Enter a challenge or pattern..."
            multiline
          />
          <TouchableOpacity style={styles.addButton} onPress={() => addIssue()}>
            <Ionicons name="add" size={20} color="white" />
          </TouchableOpacity>
        </View>
      )}

      {issues.map((issue, index) => (
        <View key={index} style={styles.item}>
          <Text style={styles.itemText}>{issue}</Text>
          <TouchableOpacity onPress={() => removeIssue(index)}>
            <Ionicons name="close" size={20} color="#ef4444" />
          </TouchableOpacity>
        </View>
      ))}

      <Text style={[styles.sectionTitle, styles.strengthsTitle]}>
        {isAIMode ? 'AI Twin Recognition' : 'Your Strengths'}
      </Text>
      <Text style={styles.sectionDescription}>
        {isAIMode 
          ? 'Your AI twin recognizes the positive qualities you bring'
          : 'What are your natural talents and positive traits?'}
      </Text>
      
      {!isAIMode && (
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            value={currentStrength}
            onChangeText={setCurrentStrength}
            placeholder="Enter a strength or positive trait..."
            multiline
          />
          <TouchableOpacity style={styles.addButton} onPress={() => addStrength()}>
            <Ionicons name="add" size={20} color="white" />
          </TouchableOpacity>
        </View>
      )}

      {strengths.map((strength, index) => (
        <View key={index} style={[styles.item, styles.strengthItem]}>
          <Text style={styles.itemText}>{strength}</Text>
          <TouchableOpacity onPress={() => removeStrength(index)}>
            <Ionicons name="close" size={20} color="#ef4444" />
          </TouchableOpacity>
        </View>
      ))}

      {(issues.length > 0 || strengths.length > 0) && (
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>
            {isAIMode ? 'Update AI Twin Profile' : 'Update Profile'}
          </Text>
        </TouchableOpacity>
      )}

      {isAIMode && (
        <Text style={styles.aiNote}>
          💡 Your AI twin will gradually share insights as you interact more
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 8,
  },
  strengthsTitle: {
    marginTop: 24,
    color: '#059669',
  },
  sectionDescription: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 16,
    lineHeight: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 8,
    padding: 12,
    marginRight: 8,
    minHeight: 44,
    textAlignVertical: 'top',
  },
  addButton: {
    backgroundColor: '#6366f1',
    borderRadius: 8,
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fef2f2',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#f87171',
  },
  strengthItem: {
    backgroundColor: '#f0fdf4',
    borderLeftColor: '#34d399',
  },
  itemText: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
    marginRight: 8,
  },
  submitButton: {
    backgroundColor: '#6366f1',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 24,
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  aiNote: {
    fontSize: 12,
    color: '#6b7280',
    textAlign: 'center',
    marginTop: 16,
    fontStyle: 'italic',
  },
});