import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import AIAvatar from './AIAvatar';

interface DecisionMakerProps {
  onCreateDecision: (scenario: string, userChoice: string) => void;
  aiMood: 'thinking' | 'confident' | 'learning';
}

export default function DecisionMaker({ onCreateDecision, aiMood }: DecisionMakerProps) {
  const [scenario, setScenario] = useState('');
  const [userChoice, setUserChoice] = useState('');

  const handleSubmit = () => {
    if (scenario.trim() && userChoice.trim()) {
      onCreateDecision(scenario, userChoice);
      setScenario('');
      setUserChoice('');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <AIAvatar mood={aiMood} size={60} />
        <Text style={styles.title}>GET AI ADVICE</Text>
      </View>
      
      <TextInput
        style={styles.input}
        placeholder="What decision are you facing?"
        placeholderTextColor="#666"
        value={scenario}
        onChangeText={setScenario}
        multiline
        numberOfLines={3}
      />
      
      <TextInput
        style={styles.input}
        placeholder="What are you thinking of doing?"
        placeholderTextColor="#666"
        value={userChoice}
        onChangeText={setUserChoice}
        multiline
        numberOfLines={2}
      />
      
      <TouchableOpacity 
        style={[styles.button, (!scenario.trim() || !userChoice.trim()) && styles.buttonDisabled]} 
        onPress={handleSubmit}
        disabled={!scenario.trim() || !userChoice.trim()}
      >
        <Text style={styles.buttonText}>GET AI SUGGESTION</Text>
      </TouchableOpacity>
      
      <Text style={styles.warning}>
        ⚠️ CHOOSE WISELY - Easy paths reset your progress
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    padding: 24,
    margin: 16,
    borderWidth: 1,
    borderColor: '#333',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 16,
    color: '#fff',
    letterSpacing: 1,
  },
  input: {
    borderWidth: 2,
    borderColor: '#333',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    marginBottom: 16,
    backgroundColor: '#0a0a0a',
    textAlignVertical: 'top',
    color: '#fff',
  },
  button: {
    backgroundColor: '#ff6b35',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
  },
  buttonDisabled: {
    backgroundColor: '#333',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 1,
  },
  warning: {
    color: '#ff6b35',
    fontSize: 12,
    textAlign: 'center',
    fontWeight: '600',
    letterSpacing: 0.5,
  },
});