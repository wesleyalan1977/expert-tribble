import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';

interface ConversationListenerProps {
  isListening: boolean;
  onToggleListening: (listening: boolean) => void;
  onRedFlagDetected: (analysis: string) => void;
  onAnalyzeConversation: (text: string) => Promise<any>;
  aiTwinName: string;
}

export default function ConversationListener({ 
  isListening, 
  onToggleListening, 
  onRedFlagDetected,
  onAnalyzeConversation,
  aiTwinName 
}: ConversationListenerProps) {
  const [analysisCount, setAnalysisCount] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isListening) {
      interval = setInterval(async () => {
        // Simulate conversation text for analysis
        const simulatedConversations = [
          'Person A: You never listen to me. Person B: That\'s not true, I always listen.',
          'Person A: You\'re being too sensitive. Person B: I don\'t think I am.',
          'Person A: I need to talk about this. Person B: Fine, whatever you want.',
          'Person A: Can we discuss this calmly? Person B: I am being calm!',
          'Person A: I feel hurt when you say that. Person B: You\'re overreacting.'
        ];
        
        const randomConvo = simulatedConversations[Math.floor(Math.random() * simulatedConversations.length)];
        
        try {
          const analysis = await onAnalyzeConversation(randomConvo);
          if (analysis && analysis.redFlags && analysis.redFlags.length > 0) {
            analysis.redFlags.forEach((flag: any) => {
              onRedFlagDetected(flag.description);
            });
          }
          setAnalysisCount(prev => prev + 1);
        } catch (error) {
          // Fallback to simple red flag detection
          const redFlags = [
            'Detected dismissive language patterns',
            'Notice interruption behavior', 
            'Observed defensive responses',
            'Identified manipulation tactics',
            'Spotted gaslighting attempt',
            'Recognized passive-aggressive tone'
          ];
          
          const randomFlag = redFlags[Math.floor(Math.random() * redFlags.length)];
          onRedFlagDetected(randomFlag);
          setAnalysisCount(prev => prev + 1);
        }
      }, 10000); // Analyze every 10 seconds
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isListening, onRedFlagDetected, onAnalyzeConversation]);

  const handleToggle = () => {
    if (!isListening) {
      Alert.alert(
        'Start Listening?',
        `${aiTwinName} will analyze conversations for red flag behaviors. This is a simulation for demo purposes.`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Start', onPress: () => onToggleListening(true) }
        ]
      );
    } else {
      onToggleListening(false);
      setAnalysisCount(0);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>🎧 Conversation Monitor</Text>
        <Text style={styles.subtitle}>
          {aiTwinName} can analyze conversations for concerning behaviors
        </Text>
        <Text style={styles.demoNote}>
          📝 Demo mode: Simulates conversation analysis
        </Text>
      </View>
      
      <TouchableOpacity 
        style={[styles.button, isListening ? styles.stopButton : styles.startButton]}
        onPress={handleToggle}
      >
        <Text style={styles.buttonText}>
          {isListening ? '⏹️ Stop Monitoring' : '🎤 Start Monitoring'}
        </Text>
      </TouchableOpacity>
      
      {isListening && (
        <View style={styles.statusContainer}>
          <Text style={styles.statusText}>🔴 Actively monitoring...</Text>
          <Text style={styles.countText}>Analyzed: {analysisCount} interactions</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  header: {
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 4,
  },
  demoNote: {
    fontSize: 12,
    color: '#9ca3af',
    fontStyle: 'italic',
  },
  button: {
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 12,
  },
  startButton: {
    backgroundColor: '#10b981',
  },
  stopButton: {
    backgroundColor: '#ef4444',
  },
  buttonText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 16,
  },
  statusContainer: {
    backgroundColor: '#f3f4f6',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  statusText: {
    color: '#ef4444',
    fontWeight: '600',
    marginBottom: 4,
  },
  countText: {
    color: '#6b7280',
    fontSize: 12,
  },
});