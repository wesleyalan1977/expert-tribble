import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';

interface PersonalityData {
  issues: string[];
  strengths: string[];
}

interface PersonalityFormProps {
  onSubmit: (data: PersonalityData) => void;
  initialData?: PersonalityData;
}

export default function PersonalityForm({ onSubmit, initialData }: PersonalityFormProps) {
  const [issues, setIssues] = useState<string[]>(initialData?.issues || ['']);
  const [strengths, setStrengths] = useState<string[]>(initialData?.strengths || ['']);

  const addIssue = () => {
    setIssues([...issues, '']);
  };

  const addStrength = () => {
    setStrengths([...strengths, '']);
  };

  const updateIssue = (index: number, value: string) => {
    const newIssues = [...issues];
    newIssues[index] = value;
    setIssues(newIssues);
  };

  const updateStrength = (index: number, value: string) => {
    const newStrengths = [...strengths];
    newStrengths[index] = value;
    setStrengths(newStrengths);
  };

  const removeIssue = (index: number) => {
    setIssues(issues.filter((_, i) => i !== index));
  };

  const removeStrength = (index: number) => {
    setStrengths(strengths.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    const filteredIssues = issues.filter(issue => issue.trim() !== '');
    const filteredStrengths = strengths.filter(strength => strength.trim() !== '');
    
    if (filteredIssues.length === 0 && filteredStrengths.length === 0) {
      Alert.alert('INCOMPLETE', 'Add at least one trait to proceed');
      return;
    }

    onSubmit({
      issues: filteredIssues,
      strengths: filteredStrengths
    });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>PERSONALITY MAPPING</Text>
      <Text style={styles.subtitle}>Identify your core patterns and strengths</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>ISSUES THAT SABOTAGE YOU</Text>
        {issues.map((issue, index) => (
          <View key={index} style={styles.inputRow}>
            <TextInput
              style={styles.input}
              value={issue}
              onChangeText={(value) => updateIssue(index, value)}
              placeholder="e.g., I avoid difficult conversations"
              placeholderTextColor="#666"
              multiline
            />
            {issues.length > 1 && (
              <TouchableOpacity onPress={() => removeIssue(index)} style={styles.removeButton}>
                <Text style={styles.removeText}>×</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
        <TouchableOpacity onPress={addIssue} style={styles.addButton}>
          <Text style={styles.addText}>+ ADD ISSUE</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>STRENGTHS THAT SERVE YOU</Text>
        {strengths.map((strength, index) => (
          <View key={index} style={styles.inputRow}>
            <TextInput
              style={styles.input}
              value={strength}
              onChangeText={(value) => updateStrength(index, value)}
              placeholder="e.g., I stay calm under pressure"
              placeholderTextColor="#666"
              multiline
            />
            {strengths.length > 1 && (
              <TouchableOpacity onPress={() => removeStrength(index)} style={styles.removeButton}>
                <Text style={styles.removeText}>×</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
        <TouchableOpacity onPress={addStrength} style={styles.addButton}>
          <Text style={styles.addText}>+ ADD STRENGTH</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity onPress={handleSubmit} style={styles.submitButton}>
        <Text style={styles.submitText}>LOCK IN PERSONALITY MAP</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 40,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    color: '#ff6b35',
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 32,
    color: '#ccc',
    letterSpacing: 1,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#ff6b35',
    letterSpacing: 1,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  input: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    color: '#fff',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333',
    fontSize: 16,
    minHeight: 60,
    textAlignVertical: 'top',
  },
  removeButton: {
    marginLeft: 12,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#ff4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  removeText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  addButton: {
    padding: 12,
    backgroundColor: '#333',
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#555',
  },
  addText: {
    color: '#ff6b35',
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  submitButton: {
    backgroundColor: '#ff6b35',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  submitText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 2,
  },
});