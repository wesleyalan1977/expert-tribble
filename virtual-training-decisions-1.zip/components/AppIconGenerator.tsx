import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export const AppIconGenerator = () => {
  return (
    <View style={styles.iconContainer}>
      <View style={styles.crown}>
        <Text style={styles.crownText}>👑</Text>
      </View>
      <View style={styles.background}>
        <View style={styles.centerGem}>
          <Text style={styles.gemText}>💎</Text>
        </View>
        <View style={styles.border} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconContainer: {
    width: 512,
    height: 512,
    backgroundColor: '#0a0a0a',
    borderRadius: 115,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  background: {
    width: 400,
    height: 400,
    backgroundColor: '#1a1a1a',
    borderRadius: 90,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 8,
    borderColor: '#ffd700',
  },
  crown: {
    position: 'absolute',
    top: 60,
    zIndex: 2,
  },
  crownText: {
    fontSize: 120,
    textAlign: 'center',
  },
  centerGem: {
    marginTop: 40,
  },
  gemText: {
    fontSize: 100,
    textAlign: 'center',
  },
  border: {
    position: 'absolute',
    width: 350,
    height: 350,
    borderRadius: 175,
    borderWidth: 4,
    borderColor: '#ff6b35',
  },
});