import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { AvatarConfig } from './AvatarCustomizer';
import AvatarCustomizer from './AvatarCustomizer';
import AvatarPreview from './AvatarPreview';
import AvatarGallery from './AvatarGallery';
import AvatarPersonalitySync from './AvatarPersonalitySync';
import AvatarExport from './AvatarExport';

export default function AvatarBuilder() {
  const [currentView, setCurrentView] = useState<'gallery' | 'customize' | 'sync' | 'export'>('gallery');
  const [currentAvatar, setCurrentAvatar] = useState<AvatarConfig>({
    face: '😊',
    body: '👤',
    accessory: '👑',
    background: '#8b5cf6',
    personality: 'Confident'
  });
  const [savedAvatars, setSavedAvatars] = useState<AvatarConfig[]>([]);

  const handleSaveAvatar = () => {
    if (savedAvatars.length >= 10) {
      Alert.alert('Limit Reached', 'You can save up to 10 avatars. Delete some to add new ones.');
      return;
    }
    setSavedAvatars([...savedAvatars, currentAvatar]);
    Alert.alert('Success', 'Avatar saved to your gallery!');
  };

  const handleSelectAvatar = (avatar: AvatarConfig) => {
    setCurrentAvatar(avatar);
    setCurrentView('customize');
  };

  const handleDeleteAvatar = (index: number) => {
    Alert.alert(
      'Delete Avatar',
      'Are you sure you want to delete this avatar?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            const newSavedAvatars = savedAvatars.filter((_, i) => i !== index);
            setSavedAvatars(newSavedAvatars);
          }
        }
      ]
    );
  };

  const renderTabBar = () => (
    <View style={styles.tabContainer}>
      <TouchableOpacity
        style={[styles.tab, currentView === 'gallery' && styles.activeTab]}
        onPress={() => setCurrentView('gallery')}
      >
        <Text style={[styles.tabText, currentView === 'gallery' && styles.activeTabText]}>Gallery</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.tab, currentView === 'customize' && styles.activeTab]}
        onPress={() => setCurrentView('customize')}
      >
        <Text style={[styles.tabText, currentView === 'customize' && styles.activeTabText]}>Create</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.tab, currentView === 'sync' && styles.activeTab]}
        onPress={() => setCurrentView('sync')}
      >
        <Text style={[styles.tabText, currentView === 'sync' && styles.activeTabText]}>Sync</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.tab, currentView === 'export' && styles.activeTab]}
        onPress={() => setCurrentView('export')}
      >
        <Text style={[styles.tabText, currentView === 'export' && styles.activeTabText]}>Share</Text>
      </TouchableOpacity>
    </View>
  );

  const renderContent = () => {
    switch (currentView) {
      case 'gallery':
        return (
          <AvatarGallery
            savedAvatars={savedAvatars}
            onSelectAvatar={handleSelectAvatar}
            onDeleteAvatar={handleDeleteAvatar}
          />
        );
      case 'customize':
        return (
          <ScrollView style={styles.customizeContainer}>
            <View style={styles.previewSection}>
              <AvatarPreview avatar={currentAvatar} size={100} />
              <TouchableOpacity style={styles.saveButton} onPress={handleSaveAvatar}>
                <Text style={styles.saveButtonText}>Save Avatar</Text>
              </TouchableOpacity>
            </View>
            <AvatarCustomizer onAvatarChange={setCurrentAvatar} />
          </ScrollView>
        );
      case 'sync':
        return (
          <ScrollView>
            <AvatarPersonalitySync 
              avatar={currentAvatar} 
              onSyncComplete={setCurrentAvatar} 
            />
          </ScrollView>
        );
      case 'export':
        return (
          <ScrollView>
            <AvatarExport avatar={currentAvatar} />
          </ScrollView>
        );
      default:
        return null;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>AI Twin Avatar Builder</Text>
        {renderTabBar()}
      </View>
      {renderContent()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1f2937',
    textAlign: 'center',
    marginBottom: 20,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#f3f4f6',
    borderRadius: 25,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: '#8b5cf6',
  },
  tabText: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
  },
  activeTabText: {
    color: 'white',
  },
  customizeContainer: {
    flex: 1,
  },
  previewSection: {
    backgroundColor: 'white',
    alignItems: 'center',
    paddingVertical: 20,
    marginBottom: 10,
  },
  saveButton: {
    backgroundColor: '#10b981',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginTop: 10,
  },
  saveButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});