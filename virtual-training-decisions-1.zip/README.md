# 👑 Melchizedek Command

**Royal Path to Mastery - Command Your Destiny**

A premium React Native app built with Expo that guides users through a 180-day journey of personal mastery and decision-making excellence.

## 🚀 Quick Start

### Option 1: Instant Deploy (Recommended)
```bash
# Make script executable and run
chmod +x scripts/deploy-now.sh
./scripts/deploy-now.sh
```

### Option 2: Manual Setup
```bash
# Install dependencies
npm install

# Start development server
npm start

# Build for production
npm run build-android
npm run build-ios
```

### Option 3: Fix Permissions (if needed)
```bash
# Fix npm permissions
chmod +x scripts/quick-fix.sh
./scripts/quick-fix.sh
```

## 📱 Features

- **180-Day Mastery Tracker** - Track continuous growth
- **AI Twin (Melchizedek)** - Personalized wisdom companion
- **Sacred Constitution** - Personal laws and principles
- **Royal Quests** - Goal setting and achievement
- **Battle Training** - Decision-making practice
- **Grit Wisdom** - Unlockable ancient knowledge
- **Premium Subscription** - Advanced features

## 🎨 Design

- **Dark Royal Theme** - Gold (#ffd700) and Orange (#ff6b35)
- **Gradient Backgrounds** - Premium visual experience
- **Responsive Layout** - Works on all devices
- **Smooth Animations** - Polished user experience

## 🔧 Tech Stack

- **React Native** with Expo
- **TypeScript** for type safety
- **Expo Router** for navigation
- **Linear Gradients** for premium styling
- **Supabase** for backend services
- **EAS Build** for deployment

## 📦 Deployment

### EAS Build Commands
```bash
# Development build
npm run build-dev

# Preview build
npm run build-preview

# Production build
npm run build-production

# Submit to stores
npm run submit-android
npm run submit-ios
```

### Environment Setup
1. Install Node.js 18+
2. Install Expo CLI: `npm install -g @expo/cli`
3. Create Expo account
4. Run deployment script

## 🏗️ Project Structure

```
app/
├── _layout.tsx          # Navigation layout
├── index.tsx            # Main command center
├── ai-twin.tsx          # AI companion
├── constitution.tsx     # Personal laws
├── goals.tsx           # Quest management
├── self.tsx            # Self-knowledge
├── train.tsx           # Decision training
└── lib/
    └── supabase.ts     # Backend config

components/
├── GritMeasure.tsx     # 180-day wisdom unlock
└── [other components]  # Feature components

hooks/
├── useUserActivity.ts  # Activity tracking
└── [other hooks]       # Custom hooks
```

## 🎯 Core Philosophy

**"No victory shall be given to those who quit."**

The app enforces a strict 180-day continuous engagement policy. Users who choose "easy paths" in decisions will have their progress reset, reinforcing the importance of grit and perseverance.

## 🔒 Premium Features

- Advanced AI personality customization
- Detailed analytics and insights
- Custom goal templates
- Priority support
- Early access to new features

## 📄 License

Proprietary - All rights reserved

## 🤝 Support

For deployment issues or questions:
1. Check the troubleshooting guide
2. Run the quick-fix script
3. Contact support team

---

**Built with ⚡ by the Melchizedek Command Team**