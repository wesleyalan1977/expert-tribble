# 🚀 QUICK START - Fix EAS CLI Issues

## IMMEDIATE SOLUTION (Use This Now!)

**You don't need to install EAS CLI globally!** Use npx instead:

```bash
# Navigate to your project directory first
cd /path/to/your/project

# Use npx (works immediately, no permissions needed)
npx eas-cli@latest init --id 6d256b00-ea43-48ab-97ed-d075954d4bd9
npx eas-cli@latest build --platform ios
npx eas-cli@latest submit --platform ios
```

## Alternative Solutions

### Option 1: Run Quick Fix Script
```bash
chmod +x scripts/quick-fix.sh
./scripts/quick-fix.sh
```

### Option 2: Manual Permission Fix
```bash
# Create npm global directory
mkdir -p ~/.npm-global
npm config set prefix '~/.npm-global'

# Add to your shell config
echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.zshrc
source ~/.zshrc

# Now install globally
npm install -g eas-cli
```

### Option 3: Use Sudo (Not Recommended)
```bash
sudo npm install -g eas-cli
```

## Project Commands (After Setup)

```bash
# Initialize EAS
eas init --id 6d256b00-ea43-48ab-97ed-d075954d4bd9

# Build for iOS
eas build --platform ios

# Submit to App Store
eas submit --platform ios

# Or use our npm scripts
npm run build:ios
npm run deploy:ios
```

## Why This Happens

The EACCES error occurs because npm tries to install global packages in `/usr/local/lib/node_modules/` which requires admin permissions. Using `npx` bypasses this entirely.

## Need Help?

See `docs/TROUBLESHOOTING.md` for detailed solutions.