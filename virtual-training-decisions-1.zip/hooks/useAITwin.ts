import { useState, useCallback } from 'react';

interface Decision {
  id: string;
  scenario: string;
  userChoice: string;
  aiSuggestion: string;
  confidence: number;
  timestamp: Date;
}

interface TrainingData {
  scenario: string;
  decision: string;
  timestamp: Date;
}

interface PersonalityData {
  issues: string[];
  strengths: string[];
}

interface RedFlag {
  id: string;
  analysis: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high';
}

export function useAITwin() {
  const [trainingData, setTrainingData] = useState<TrainingData[]>([]);
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [personalityData, setPersonalityData] = useState<PersonalityData>({ issues: [], strengths: [] });
  const [aiMood, setAiMood] = useState<'thinking' | 'confident' | 'learning'>('learning');
  const [aiTwinName, setAiTwinName] = useState('Melchizedek');
  const [redFlags, setRedFlags] = useState<RedFlag[]>([]);
  const [isListening, setIsListening] = useState(false);

  const trainAI = useCallback((scenario: string, decision: string) => {
    const newData: TrainingData = {
      scenario,
      decision,
      timestamp: new Date(),
    };
    setTrainingData(prev => [...prev, newData]);
    setAiMood('learning');
  }, []);

  const updatePersonality = useCallback((data: PersonalityData) => {
    setPersonalityData(data);
    setAiMood('learning');
  }, []);

  const updateAITwinName = useCallback((name: string) => {
    setAiTwinName(name);
  }, []);

  const analyzeConversation = useCallback(async (conversationText: string) => {
    try {
      const response = await fetch(
        'https://ysdrwaiivfkjpdgbujdn.supabase.co/functions/v1/2ecaa155-e12c-4b42-b252-770e2e5b0321',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            conversation: conversationText,
            aiTwinName
          })
        }
      );
      
      const analysis = await response.json();
      
      if (analysis.redFlags && analysis.redFlags.length > 0) {
        const newFlags: RedFlag[] = analysis.redFlags.map((flag: any) => ({
          id: Date.now().toString() + Math.random(),
          analysis: flag.description,
          timestamp: new Date(),
          severity: flag.severity
        }));
        
        setRedFlags(prev => [...newFlags, ...prev].slice(0, 20));
      }
      
      return analysis;
    } catch (error) {
      console.error('Conversation analysis failed:', error);
      return null;
    }
  }, [aiTwinName]);

  const toggleListening = useCallback((listening: boolean) => {
    setIsListening(listening);
  }, []);

  const clearRedFlags = useCallback(() => {
    setRedFlags([]);
  }, []);

  const generateAISuggestion = useCallback((scenario: string, conversationInsights?: string): string => {
    const keywords = scenario.toLowerCase().split(' ');
    
    const relevantIssues = personalityData.issues.filter(issue =>
      keywords.some(keyword => issue.toLowerCase().includes(keyword))
    );
    
    const relevantStrengths = personalityData.strengths.filter(strength =>
      keywords.some(keyword => strength.toLowerCase().includes(keyword))
    );

    const relevantTraining = trainingData.filter(data => 
      keywords.some(keyword => data.scenario.toLowerCase().includes(keyword))
    );

    let suggestion = '';
    
    if (conversationInsights) {
      suggestion += conversationInsights + ' ';
    }
    
    if (relevantIssues.length > 0) {
      suggestion += `Watch out for: ${relevantIssues[0]}. `;
    }
    
    if (relevantStrengths.length > 0) {
      suggestion += `Use your strength: ${relevantStrengths[0]}. `;
    }
    
    if (relevantTraining.length > 0) {
      const mostRecent = relevantTraining[relevantTraining.length - 1];
      suggestion += `Based on past decisions: ${mostRecent.decision}`;
    } else {
      if (keywords.includes('work') || keywords.includes('job') || keywords.includes('career')) {
        suggestion += 'Focus on long-term career growth and skill development';
      } else if (keywords.includes('health') || keywords.includes('exercise') || keywords.includes('fitness')) {
        suggestion += 'Prioritize consistency over intensity for lasting results';
      } else if (keywords.includes('money') || keywords.includes('financial') || keywords.includes('budget')) {
        suggestion += 'Consider the 50/30/20 budgeting rule: needs, wants, savings';
      } else if (keywords.includes('relationship') || keywords.includes('friend') || keywords.includes('family')) {
        suggestion += 'Communicate openly and listen with empathy';
      } else {
        suggestion += 'Reflect on your values and long-term goals before deciding';
      }
    }
    
    return suggestion || 'Take time to think this through carefully and trust your instincts';
  }, [trainingData, personalityData]);

  const createDecision = useCallback((scenario: string, userChoice: string, conversationInsights?: string) => {
    const aiSuggestion = generateAISuggestion(scenario, conversationInsights);
    const baseConfidence = 60;
    const trainingBonus = Math.min(20, trainingData.length * 2);
    const personalityBonus = Math.min(10, (personalityData.issues.length + personalityData.strengths.length));
    const conversationBonus = conversationInsights ? 10 : 0;
    const confidence = Math.min(95, baseConfidence + trainingBonus + personalityBonus + conversationBonus);
    
    const newDecision: Decision = {
      id: Date.now().toString(),
      scenario,
      userChoice,
      aiSuggestion,
      confidence,
      timestamp: new Date(),
    };
    
    setDecisions(prev => [newDecision, ...prev]);
    setAiMood('confident');
    return newDecision;
  }, [generateAISuggestion, trainingData.length, personalityData]);

  return {
    trainingData,
    decisions,
    personalityData,
    aiMood,
    aiTwinName,
    redFlags,
    isListening,
    trainAI,
    updatePersonality,
    updateAITwinName,
    analyzeConversation,
    toggleListening,
    clearRedFlags,
    createDecision,
    generateAISuggestion,
  };
}