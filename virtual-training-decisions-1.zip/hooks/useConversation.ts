import { useState, useCallback } from 'react';

interface ConversationData {
  detectedTraits: string[];
  goals: string[];
  selectedGoal: string | null;
}

export function useConversation() {
  const [conversationData, setConversationData] = useState<ConversationData>({
    detectedTraits: [],
    goals: [],
    selectedGoal: null
  });

  const addDetectedTraits = useCallback((traits: string[]) => {
    setConversationData(prev => ({
      ...prev,
      detectedTraits: [...new Set([...prev.detectedTraits, ...traits])]
    }));
  }, []);

  const setGoals = useCallback((goals: string[]) => {
    setConversationData(prev => ({ ...prev, goals }));
  }, []);

  const selectGoal = useCallback((goal: string) => {
    setConversationData(prev => ({ ...prev, selectedGoal: goal }));
  }, []);

  const generatePersonalizedSuggestion = useCallback((scenario: string) => {
    const { selectedGoal, detectedTraits } = conversationData;
    let suggestion = '';
    
    if (selectedGoal === 'Emotional Mastery') {
      suggestion = 'Consider how this aligns with developing emotional intelligence. ';
    } else if (selectedGoal === 'Consistent Excellence') {
      suggestion = 'Think about building sustainable habits here. ';
    } else if (selectedGoal === 'Authentic Connection') {
      suggestion = 'Consider how this impacts your relationships. ';
    }
    
    if (detectedTraits.includes('anxiety tendencies')) {
      suggestion += 'Take a moment to breathe and center yourself. ';
    }
    if (detectedTraits.includes('procrastination')) {
      suggestion += 'Break this into smaller steps. ';
    }
    
    return suggestion || 'Reflect on your values and long-term vision.';
  }, [conversationData]);

  return {
    conversationData,
    addDetectedTraits,
    setGoals,
    selectGoal,
    generatePersonalizedSuggestion
  };
}