import { useState, useEffect } from 'react';
import { supabase } from '../app/lib/supabase';

export interface UserActivity {
  continuousDays: number;
  isEligible: boolean;
  isLoading: boolean;
  easyPathCount: number;
}

export const useUserActivity = () => {
  const [activity, setActivity] = useState<UserActivity>({
    continuousDays: 1,
    isEligible: false,
    isLoading: true,
    easyPathCount: 0
  });

  const loadUserActivity = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      const { data, error } = await supabase
        .from('user_activity')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (error && error.code !== 'PGRST116') {
        throw error;
      }
      
      if (data) {
        const days = Math.max(data.continuous_days || 1, 1);
        setActivity({
          continuousDays: days,
          isEligible: days >= 180,
          isLoading: false,
          easyPathCount: data.easy_path_count || 0
        });
      } else {
        await createUserActivity(user.id);
      }
    } catch (error) {
      console.error('Error loading activity:', error);
      setActivity(prev => ({ ...prev, isLoading: false }));
    }
  };
  
  const createUserActivity = async (userId: string) => {
    const { error } = await supabase
      .from('user_activity')
      .insert({
        user_id: userId,
        continuous_days: 1,
        last_activity_date: new Date().toISOString(),
        easy_path_count: 0
      });
    
    if (error) throw error;
    
    setActivity({
      continuousDays: 1,
      isEligible: false,
      isLoading: false,
      easyPathCount: 0
    });
  };

  const recordDailyActivity = async (): Promise<void> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      const today = new Date().toDateString();
      
      const { data, error } = await supabase
        .from('user_activity')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (error) {
        await createUserActivity(user.id);
        return;
      }
      
      let continuousDays = Math.max(data.continuous_days || 1, 1);
      const lastActivity = data.last_activity_date;
      
      if (lastActivity) {
        const lastDate = new Date(lastActivity);
        const todayDate = new Date(today);
        const diffTime = todayDate.getTime() - lastDate.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
          continuousDays += 1;
        } else if (diffDays > 1) {
          continuousDays = 1;
        }
      } else {
        continuousDays = 1;
      }
      
      await supabase
        .from('user_activity')
        .update({
          continuous_days: continuousDays,
          last_activity_date: new Date().toISOString()
        })
        .eq('user_id', user.id);
      
      setActivity({
        continuousDays,
        isEligible: continuousDays >= 180,
        isLoading: false,
        easyPathCount: data.easy_path_count || 0
      });
    } catch (error) {
      console.error('Error recording activity:', error);
    }
  };
  
  const resetTracker = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      await supabase
        .from('user_activity')
        .update({ 
          continuous_days: 1,
          last_activity_date: new Date().toISOString()
        })
        .eq('user_id', user.id);
      
      setActivity(prev => ({
        ...prev,
        continuousDays: 1,
        isEligible: false
      }));
    } catch (error) {
      console.error('Error resetting tracker:', error);
    }
  };

  useEffect(() => {
    loadUserActivity();
  }, []);

  return {
    ...activity,
    recordDailyActivity,
    resetTracker,
    loadUserActivity
  };
};