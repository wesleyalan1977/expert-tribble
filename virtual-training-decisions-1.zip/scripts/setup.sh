#!/bin/bash

# Setup script for Know Thyself - Melchizedek's Command
# Handles EAS CLI installation and project setup

set -e

echo "🔱 Setting up Know Thyself - Melchizedek's Command"
echo "================================================"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    echo "   Visit: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"

# Check npm version
echo "✅ npm version: $(npm --version)"

# Install project dependencies
echo "📦 Installing project dependencies..."
npm install

# Check if EAS CLI is available
if ! command -v eas &> /dev/null; then
    echo "⚠️  EAS CLI not found globally"
    echo "💡 We'll use npx to run EAS commands"
    echo "   This avoids permission issues"
else
    echo "✅ EAS CLI is available"
fi

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cat > .env << EOF
# Supabase Configuration
SUPABASE_URL=your_supabase_url_here
SUPABASE_ANON_KEY=your_supabase_anon_key_here

# App Configuration
APP_ENV=development
EOF
    echo "✅ Created .env file - please update with your Supabase credentials"
fi

# Create docs directory if it doesn't exist
mkdir -p docs

echo ""
echo "🎉 Setup complete!"
echo ""
echo "Next steps:"
echo "1. Update .env with your Supabase credentials"
echo "2. Start development server: npm start"
echo "3. Run on device: npm run ios or npm run android"
echo ""
echo "For EAS builds (use npx to avoid permission issues):"
echo "• Configure: npx eas build:configure"
echo "• Build: npx eas build --platform all"
echo "• Submit: npx eas submit"
echo ""
echo "📚 See docs/DEPLOYMENT.md for detailed deployment instructions"
echo "🔱 May your path to self-knowledge be illuminated!"
