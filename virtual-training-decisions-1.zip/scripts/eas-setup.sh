#!/bin/bash

# EAS CLI Setup Script
# Handles installation and project initialization

set -e

echo "🚀 Setting up EAS CLI for your project..."
echo "=========================================="

# Check if we can use global EAS CLI
if command -v eas &> /dev/null; then
    echo "✅ EAS CLI already installed globally"
    EAS_CMD="eas"
else
    echo "⚠️  EAS CLI not found globally, using npx"
    EAS_CMD="npx eas-cli@latest"
fi

# Initialize EAS project with provided ID
echo "🔧 Initializing EAS project..."
if [ "$1" ]; then
    PROJECT_ID="$1"
else
    PROJECT_ID="6d256b00-ea43-48ab-97ed-d075954d4bd9"
fi

echo "📱 Using project ID: $PROJECT_ID"

# Run EAS init
$EAS_CMD init --id $PROJECT_ID

# Configure build profiles if not exists
if [ ! -f "eas.json" ]; then
    echo "⚙️  Configuring build profiles..."
    $EAS_CMD build:configure
fi

echo "✅ EAS setup complete!"
echo ""
echo "Next steps:"
echo "1. Build development: $EAS_CMD build --profile development"
echo "2. Build preview: $EAS_CMD build --profile preview"
echo "3. Build production: $EAS_CMD build --profile production"
echo ""
echo "🎯 Ready to deploy your AI twin app!"
