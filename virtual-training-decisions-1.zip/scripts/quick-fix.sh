#!/bin/bash

# Quick fix for EAS CLI permission issues
# This script provides immediate solutions without requiring global installs

set -e

echo "🚀 Quick EAS CLI Fix"
echo "=================="

# Check if we're in a React Native/Expo project
if [ ! -f "package.json" ]; then
    echo "❌ Error: Not in a React Native project directory"
    echo "Please navigate to your project folder first"
    exit 1
fi

# Solution 1: Use npx (recommended)
echo "✅ Solution 1: Using npx (no global install needed)"
echo "Run these commands instead:"
echo "  npx eas-cli@latest init --id 6d256b00-ea43-48ab-97ed-d075954d4bd9"
echo "  npx eas-cli@latest build --platform ios"
echo "  npx eas-cli@latest submit --platform ios"
echo ""

# Solution 2: Install as dev dependency
echo "✅ Solution 2: Installing EAS CLI as project dependency..."
npm install --save-dev eas-cli
echo "Now you can use: npx eas init --id 6d256b00-ea43-48ab-97ed-d075954d4bd9"
echo ""

# Solution 3: Fix npm permissions
echo "✅ Solution 3: Fixing npm permissions..."
mkdir -p ~/.npm-global
npm config set prefix '~/.npm-global'

# Update shell config
if [[ $SHELL == *"zsh"* ]]; then
    SHELL_CONFIG="$HOME/.zshrc"
else
    SHELL_CONFIG="$HOME/.bashrc"
fi

if ! grep -q "npm-global" "$SHELL_CONFIG" 2>/dev/null; then
    echo "export PATH=~/.npm-global/bin:\$PATH" >> "$SHELL_CONFIG"
    echo "Added npm-global to PATH in $SHELL_CONFIG"
fi

echo ""
echo "🎉 Quick fixes applied!"
echo ""
echo "IMMEDIATE SOLUTION (use this now):"
echo "  npx eas-cli@latest init --id 6d256b00-ea43-48ab-97ed-d075954d4bd9"
echo ""
echo "After restarting terminal, you can also use:"
echo "  npm install -g eas-cli"
echo "  eas init --id 6d256b00-ea43-48ab-97ed-d075954d4bd9"
