#!/bin/bash

# Complete deployment script for AI Twin app
# Handles permissions, EAS setup, and build process

set -e

echo "🎯 AI Twin App Deployment Script"
echo "==============================="

# Step 1: Fix npm permissions if needed
echo "🔧 Step 1: Checking npm permissions..."
if npm list -g eas-cli &> /dev/null; then
    echo "✅ EAS CLI already installed globally"
else
    echo "⚠️  EAS CLI not found, checking permissions..."
    if npm install -g --dry-run eas-cli &> /dev/null; then
        echo "✅ Permissions OK, installing EAS CLI..."
        npm install -g eas-cli
    else
        echo "❌ Permission issues detected, running fix..."
        chmod +x scripts/fix-permissions.sh
        ./scripts/fix-permissions.sh
        echo "🔄 Please restart terminal and run this script again"
        exit 1
    fi
fi

# Step 2: Initialize EAS project
echo "🚀 Step 2: Setting up EAS project..."
chmod +x scripts/eas-setup.sh
./scripts/eas-setup.sh 6d256b00-ea43-48ab-97ed-d075954d4bd9

# Step 3: Install dependencies
echo "📦 Step 3: Installing dependencies..."
npm install

# Step 4: Build for development
echo "🔨 Step 4: Creating development build..."
if command -v eas &> /dev/null; then
    eas build --profile development --platform all
else
    npx eas-cli@latest build --profile development --platform all
fi

echo "🎉 Deployment complete!"
echo "Check your build status at: https://expo.dev/"
