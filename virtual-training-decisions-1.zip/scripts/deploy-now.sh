#!/bin/bash

# Melchizedek Command - Quick Deploy Script
echo "🚀 Starting Melchizedek Command deployment..."

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from the project root."
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Install EAS CLI locally if not available
if ! command -v npx eas-cli &> /dev/null; then
    echo "📱 Installing EAS CLI..."
    npm install --save-dev eas-cli@latest
fi

# Login to EAS (if not already logged in)
echo "🔐 Checking EAS login..."
npx eas-cli@latest whoami || {
    echo "Please login to EAS:"
    npx eas-cli@latest login
}

# Initialize EAS project
echo "⚙️ Initializing EAS project..."
npx eas-cli@latest init --id 6d256b00-ea43-48ab-97ed-d075954d4bd9 --non-interactive || true

# Build for preview
echo "🏗️ Building preview version..."
npx eas-cli@latest build --platform android --profile preview --non-interactive

echo "✅ Deployment complete!"
echo "📱 Your app is now building. Check the EAS dashboard for progress."
echo "🌐 Dashboard: https://expo.dev/accounts/your-account/projects/melchizedek-command"

# Optional: Start development server
read -p "🔥 Start development server? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    npm start
fi