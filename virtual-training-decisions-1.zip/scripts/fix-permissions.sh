#!/bin/bash

# Fix npm permission issues script
# Resolves EACCES errors when installing global packages

set -e

echo "🔧 Fixing npm permission issues..."
echo "==================================="

# Create npm global directory
echo "📁 Creating npm global directory..."
mkdir -p ~/.npm-global

# Set npm prefix
echo "⚙️  Configuring npm prefix..."
npm config set prefix '~/.npm-global'

# Detect shell and update PATH
if [[ $SHELL == *"zsh"* ]]; then
    SHELL_CONFIG="~/.zshrc"
    echo "🐚 Detected zsh shell"
elif [[ $SHELL == *"bash"* ]]; then
    SHELL_CONFIG="~/.bashrc"
    echo "🐚 Detected bash shell"
else
    SHELL_CONFIG="~/.profile"
    echo "🐚 Using default profile"
fi

# Add to PATH if not already present
PATH_EXPORT="export PATH=~/.npm-global/bin:\$PATH"
if ! grep -q "npm-global" $SHELL_CONFIG 2>/dev/null; then
    echo "📝 Adding npm-global to PATH in $SHELL_CONFIG"
    echo "" >> $SHELL_CONFIG
    echo "# npm global packages" >> $SHELL_CONFIG
    echo "$PATH_EXPORT" >> $SHELL_CONFIG
else
    echo "✅ PATH already configured"
fi

# Source the shell config
echo "🔄 Reloading shell configuration..."
source $SHELL_CONFIG 2>/dev/null || true

# Verify npm configuration
echo "✅ npm prefix: $(npm config get prefix)"
echo "✅ npm cache: $(npm config get cache)"

echo ""
echo "🎉 Permission fix complete!"
echo ""
echo "Next steps:"
echo "1. Restart your terminal or run: source $SHELL_CONFIG"
echo "2. Test with: npm install -g eas-cli"
echo "3. Or continue using npx: npx eas-cli@latest"
echo ""
echo "🔱 Your path to deployment mastery is now clear!"
